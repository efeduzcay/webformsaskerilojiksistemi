using System;
using System.Collections.Generic;

namespace ECommerceWebForms
{
    public partial class ProductDetailPage : System.Web.UI.Page
    {
        private Product currentProduct;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadProduct();
            }
        }

        private void LoadProduct()
        {
            try
            {
                if (Request.QueryString["id"] == null)
                {
                    ShowNotFound();
                    return;
                }

                int productId = Convert.ToInt32(Request.QueryString["id"]);
                ProductRepo productRepo = new ProductRepo();
                currentProduct = productRepo.GetById(productId);

                if (currentProduct == null || !currentProduct.IsActive)
                {
                    ShowNotFound();
                    return;
                }

                // Sayfa başlığı
                Page.Title = currentProduct.ProductName;

                // Bilgileri doldur
                lblCategory.Text = currentProduct.CategoryName;
                lblProductName.Text = currentProduct.ProductName;
                lblDescription.Text = currentProduct.Description;
                lblPrice.Text = currentProduct.Price.ToString("N2");
                lblStock.Text = currentProduct.StockQuantity.ToString();

                // Stok durumuna göre badge rengi
                // Stok durumuna göre badge rengi
                System.Web.UI.HtmlControls.HtmlGenericControl badge = (System.Web.UI.HtmlControls.HtmlGenericControl)lblStock.Parent;
                if (currentProduct.StockQuantity > 10)
                {
                    badge.Attributes["class"] = "badge badge-success";
                }
                else if (currentProduct.StockQuantity > 0)
                {
                    badge.Attributes["class"] = "badge badge-warning";
                }
                else
                {
                    badge.Attributes["class"] = "badge badge-danger";
                    btnAddToCart.Enabled = false;
                    btnAddToCart.Text = "Stokta Yok";
                }

                // Görsel
                if (!string.IsNullOrEmpty(currentProduct.ImageUrl))
                {
                    imgProduct.ImageUrl = currentProduct.ImageUrl;
                }
                else
                {
                    imgProduct.ImageUrl = "~/Uploads/no-image.png";
                }
            }
            catch (Exception ex)
            {
                ShowNotFound();
            }
        }

        private void ShowNotFound()
        {
            pnlProduct.Visible = false;
            pnlNotFound.Visible = true;
        }

        protected void btnAddToCart_Click(object sender, EventArgs e)
        {
            if (Session["UserID"] == null)
            {
                Response.Redirect("~/Login.aspx?returnUrl=" + Server.UrlEncode(Request.Url.PathAndQuery));
                return;
            }

            try
            {
                int productId = Convert.ToInt32(Request.QueryString["id"]);
                int quantity = 1;
                int.TryParse(txtQuantity.Text, out quantity);
                if (quantity < 1) quantity = 1;

                ProductRepo productRepo = new ProductRepo();
                Product product = productRepo.GetById(productId);

                if (product != null)
                {
                    if (quantity > product.StockQuantity)
                    {
                        ShowError("Yeterli stok yok. Mevcut stok: " + product.StockQuantity);
                        return;
                    }

                    List<CartItem> cart = Session["Cart"] as List<CartItem>;
                    if (cart == null)
                    {
                        cart = new List<CartItem>();
                    }

                    // Sepette var mı kontrol et
                    CartItem existingItem = cart.Find(x => x.ProductID == productId);
                    if (existingItem != null)
                    {
                        existingItem.Quantity += quantity;
                    }
                    else
                    {
                        cart.Add(new CartItem
                        {
                            ProductID = product.ProductID,
                            ProductName = product.ProductName,
                            UnitPrice = product.Price,
                            Quantity = quantity,
                            ImageUrl = product.ImageUrl
                        });
                    }

                    Session["Cart"] = cart;
                    ShowSuccess(quantity + " adet " + product.ProductName + " sepete eklendi!");
                }
            }
            catch (Exception ex)
            {
                ShowError("Sepete eklenirken hata: " + ex.Message);
            }
        }

        private void ShowSuccess(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-success";
            lblMessage.Text = message;
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}

