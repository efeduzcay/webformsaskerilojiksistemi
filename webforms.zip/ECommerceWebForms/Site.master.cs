using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;

namespace ECommerceWebForms
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BuildMenu();
                UpdateUserInfo();
                UpdateCartInfo();
            }
        }

        /// <summary>
        /// Dinamik menü oluşturur - Rol bazlı
        /// </summary>
        private void BuildMenu()
        {
            MainMenu.Items.Clear();

            // Herkese açık menüler
            MainMenu.Items.Add(new MenuItem("Ana Sayfa", "", "", ResolveUrl("~/Default.aspx")));
            MainMenu.Items.Add(new MenuItem("Ürünler", "", "", ResolveUrl("~/Products.aspx")));

            // Giriş yapmış kullanıcı menüleri
            if (Session["UserID"] != null)
            {
                int roleId = Session["RoleID"] != null ? Convert.ToInt32(Session["RoleID"]) : 0;

                // User menüleri (Admin dahil herkese)
                MenuItem userMenu = new MenuItem("Hesabım", "", "", "");
                userMenu.ChildItems.Add(new MenuItem("Profilim", "", "", ResolveUrl("~/User/Profile.aspx")));
                userMenu.ChildItems.Add(new MenuItem("Siparişlerim", "", "", ResolveUrl("~/User/Orders.aspx")));
                userMenu.ChildItems.Add(new MenuItem("Sepetim", "", "", ResolveUrl("~/User/Cart.aspx")));
                MainMenu.Items.Add(userMenu);

                // Admin menüleri (RoleID = 1)
                if (roleId == 1)
                {
                    MenuItem adminMenu = new MenuItem("Admin Panel", "", "", "");
                    adminMenu.ChildItems.Add(new MenuItem("Dashboard", "", "", ResolveUrl("~/Admin/Default.aspx")));
                    adminMenu.ChildItems.Add(new MenuItem("Kategoriler", "", "", ResolveUrl("~/Admin/Categories.aspx")));
                    adminMenu.ChildItems.Add(new MenuItem("Ürünler", "", "", ResolveUrl("~/Admin/Products.aspx")));
                    adminMenu.ChildItems.Add(new MenuItem("Siparişler", "", "", ResolveUrl("~/Admin/Orders.aspx")));
                    adminMenu.ChildItems.Add(new MenuItem("Kullanıcılar", "", "", ResolveUrl("~/Admin/Users.aspx")));
                    MainMenu.Items.Add(adminMenu);
                }
            }
        }

        /// <summary>
        /// LoginView içindeki kullanıcı adını günceller
        /// </summary>
        private void UpdateUserInfo()
        {
            if (Session["UserID"] != null)
            {
                // LoginView LoggedInTemplate'i aktif et
                Literal litUsername = LoginView1.FindControl("litUsername") as Literal;
                if (litUsername != null)
                {
                    litUsername.Text = Session["FullName"] != null ? Session["FullName"].ToString() : Session["Username"].ToString();
                }
            }
        }

        /// <summary>
        /// Sepet bilgisini günceller
        /// </summary>
        private void UpdateCartInfo()
        {
            if (Session["UserID"] != null)
            {
                pnlCart.Visible = true;
                List<CartItem> cart = Session["Cart"] as List<CartItem>;
                if (cart != null)
                {
                    int totalItems = 0;
                    foreach (CartItem item in cart)
                    {
                        totalItems += item.Quantity;
                    }
                    litCartCount.Text = totalItems.ToString();
                }
            }
        }

        /// <summary>
        /// Çıkış işlemi
        /// </summary>
        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Abandon();
            System.Web.Security.FormsAuthentication.SignOut();
            Response.Redirect("~/Default.aspx");
        }
    }
}

