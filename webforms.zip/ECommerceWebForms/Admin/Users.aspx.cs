using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ECommerceWebForms.Admin
{
    public partial class AdminUsersPage : BasePage
    {
        protected override int RequiredRoleId { get { return 1; } }
        protected override bool RequiresLogin { get { return true; } }

        private List<Role> roles;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadRoles();
                LoadUsers();
            }
        }

        private void LoadRoles()
        {
            RoleRepo roleRepo = new RoleRepo();
            roles = roleRepo.GetAll();
            ViewState["Roles"] = roles;
        }

        private void LoadUsers()
        {
            try
            {
                UserRepo userRepo = new UserRepo();
                List<UserModel> users = userRepo.GetAll();

                gvUsers.DataSource = users;
                gvUsers.DataBind();
            }
            catch (Exception ex)
            {
                ShowError("Kullanıcılar yüklenirken hata: " + ex.Message);
            }
        }

        protected void gvUsers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DropDownList ddlRole = (DropDownList)e.Row.FindControl("ddlRole");
                if (ddlRole != null)
                {
                    List<Role> roleList = ViewState["Roles"] as List<Role>;
                    if (roleList != null)
                    {
                        foreach (Role role in roleList)
                        {
                            ddlRole.Items.Add(new ListItem(role.RoleName, role.RoleID.ToString()));
                        }
                    }

                    // Mevcut rolü seç
                    UserModel UserModel = (UserModel)e.Row.DataItem;
                    ddlRole.SelectedValue = UserModel.RoleID.ToString();
                }
            }
        }

        protected void gvUsers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvUsers.PageIndex = e.NewPageIndex;
            LoadRoles();
            LoadUsers();
        }

        protected void gvUsers_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "UpdateRole")
            {
                int userId = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = (GridViewRow)((LinkButton)e.CommandSource).NamingContainer;
                DropDownList ddlRole = (DropDownList)row.FindControl("ddlRole");

                try
                {
                    UserRepo userRepo = new UserRepo();
                    int result = userRepo.UpdateRole(userId, Convert.ToInt32(ddlRole.SelectedValue));
                    if (result > 0)
                    {
                        ShowSuccess("Kullanıcı rolü güncellendi.");
                        LoadRoles();
                        LoadUsers();
                    }
                }
                catch (Exception ex)
                {
                    ShowError("Rol güncelleme hatası: " + ex.Message);
                }
            }
            else if (e.CommandName == "ToggleStatus")
            {
                string[] args = e.CommandArgument.ToString().Split(',');
                int userId = Convert.ToInt32(args[0]);
                bool currentStatus = Convert.ToBoolean(args[1]);

                try
                {
                    UserRepo userRepo = new UserRepo();
                    int result = userRepo.UpdateStatus(userId, !currentStatus);
                    if (result > 0)
                    {
                        ShowSuccess("Kullanıcı durumu güncellendi.");
                        LoadRoles();
                        LoadUsers();
                    }
                }
                catch (Exception ex)
                {
                    ShowError("Durum güncelleme hatası: " + ex.Message);
                }
            }
        }

        private void ShowSuccess(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-success";
            lblMessage.Text = message;
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}

