using System;
using System.Data;

namespace ECommerceWebForms.Admin
{
    public partial class AdminDefaultPage : BasePage
    {
        protected override int RequiredRoleId { get { return 1; } }
        protected override bool RequiresLogin { get { return true; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadStatistics();
            }
        }

        private void LoadStatistics()
        {
            try
            {
                // Ürün sayısı
                object productCount = Db.ExecuteScalar("SELECT COUNT(*) FROM Products");
                lblProductCount.Text = productCount != null ? productCount.ToString() : "0";

                // Kategori sayısı
                object categoryCount = Db.ExecuteScalar("SELECT COUNT(*) FROM Categories");
                lblCategoryCount.Text = categoryCount != null ? categoryCount.ToString() : "0";

                // Kullanıcı sayısı
                object userCount = Db.ExecuteScalar("SELECT COUNT(*) FROM Users");
                lblUserCount.Text = userCount != null ? userCount.ToString() : "0";

                // Sipariş sayısı
                object orderCount = Db.ExecuteScalar("SELECT COUNT(*) FROM Orders");
                lblOrderCount.Text = orderCount != null ? orderCount.ToString() : "0";

                // Bekleyen sipariş sayısı
                OrderRepo orderRepo = new OrderRepo();
                lblPendingOrders.Text = orderRepo.GetCountByStatus("Beklemede").ToString();
            }
            catch (Exception ex)
            {
                // Hata durumunda 0 göster
            }
        }
    }
}

