using System;
using System.Collections.Generic;
using System.IO;
using System.Web.UI.WebControls;

namespace ECommerceWebForms.Admin
{
    public partial class AdminProductsPage : BasePage
    {
        protected override int RequiredRoleId { get { return 1; } }
        protected override bool RequiresLogin { get { return true; } }

        // İzin verilen uzantılar
        private readonly string[] allowedExtensions = { ".jpg", ".jpeg", ".png", ".gif" };

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCategories();
                LoadProducts();
            }
        }

        private void LoadCategories()
        {
            try
            {
                CategoryRepo categoryRepo = new CategoryRepo();
                List<Category> categories = categoryRepo.GetAll();

                // Filter dropdown
                ddlCategoryFilter.Items.Clear();
                ddlCategoryFilter.Items.Add(new ListItem("Tüm Kategoriler", "0"));

                // Form dropdown
                ddlCategory.Items.Clear();
                ddlCategory.Items.Add(new ListItem("-- Kategori Seçin --", "0"));

                foreach (Category cat in categories)
                {
                    ddlCategoryFilter.Items.Add(new ListItem(cat.CategoryName, cat.CategoryID.ToString()));
                    if (cat.IsActive)
                    {
                        ddlCategory.Items.Add(new ListItem(cat.CategoryName, cat.CategoryID.ToString()));
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Kategoriler yüklenirken hata: " + ex.Message);
            }
        }

        private void LoadProducts()
        {
            try
            {
                ProductRepo productRepo = new ProductRepo();
                List<Product> products = productRepo.GetAll();

                // Arama filtresi
                string keyword = txtSearch.Text.Trim();
                if (!string.IsNullOrEmpty(keyword))
                {
                    products = products.FindAll(p => 
                        p.ProductName.ToLower().Contains(keyword.ToLower()) ||
                        (p.Description != null && p.Description.ToLower().Contains(keyword.ToLower())));
                }

                // Kategori filtresi
                int categoryId = Convert.ToInt32(ddlCategoryFilter.SelectedValue);
                if (categoryId > 0)
                {
                    products = products.FindAll(p => p.CategoryID == categoryId);
                }

                // Sıralama
                ApplySorting(ref products);

                gvProducts.DataSource = products;
                gvProducts.DataBind();
            }
            catch (Exception ex)
            {
                ShowError("Ürünler yüklenirken hata: " + ex.Message);
            }
        }

        private string SortExpression
        {
            get { return ViewState["SortExpression"] as string ?? "ProductName"; }
            set { ViewState["SortExpression"] = value; }
        }

        private string SortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private void ApplySorting(ref List<Product> products)
        {
            switch (SortExpression)
            {
                case "ProductID":
                    products.Sort((a, b) => SortDirection == "ASC" ? a.ProductID.CompareTo(b.ProductID) : b.ProductID.CompareTo(a.ProductID));
                    break;
                case "ProductName":
                    products.Sort((a, b) => SortDirection == "ASC" ? a.ProductName.CompareTo(b.ProductName) : b.ProductName.CompareTo(a.ProductName));
                    break;
                case "Price":
                    products.Sort((a, b) => SortDirection == "ASC" ? a.Price.CompareTo(b.Price) : b.Price.CompareTo(a.Price));
                    break;
                case "StockQuantity":
                    products.Sort((a, b) => SortDirection == "ASC" ? a.StockQuantity.CompareTo(b.StockQuantity) : b.StockQuantity.CompareTo(a.StockQuantity));
                    break;
            }
        }

        protected void gvProducts_Sorting(object sender, GridViewSortEventArgs e)
        {
            SortDirection = (SortExpression == e.SortExpression && SortDirection == "ASC") ? "DESC" : "ASC";
            SortExpression = e.SortExpression;
            LoadProducts();
        }

        protected void gvProducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvProducts.PageIndex = e.NewPageIndex;
            LoadProducts();
        }

        protected void gvProducts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditProduct")
            {
                int productId = Convert.ToInt32(e.CommandArgument);
                LoadProductForEdit(productId);
            }
        }

        protected void gvProducts_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                int productId = Convert.ToInt32(gvProducts.DataKeys[e.RowIndex].Value);
                ProductRepo productRepo = new ProductRepo();

                // Ürünü bul ve görselini sil
                Product product = productRepo.GetById(productId);
                if (product != null && !string.IsNullOrEmpty(product.ImageUrl))
                {
                    string imagePath = Server.MapPath(product.ImageUrl);
                    if (File.Exists(imagePath))
                    {
                        File.Delete(imagePath);
                    }
                }

                int result = productRepo.Delete(productId);
                if (result > 0)
                {
                    ShowSuccess("Ürün başarıyla silindi.");
                    LoadProducts();
                }
                else
                {
                    ShowError("Ürün silinemedi.");
                }
            }
            catch (Exception ex)
            {
                ShowError("Silme hatası: " + ex.Message);
            }
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            ClearForm();
            pnlForm.Visible = true;
        }

        private void LoadProductForEdit(int productId)
        {
            try
            {
                ProductRepo productRepo = new ProductRepo();
                Product product = productRepo.GetById(productId);

                if (product != null)
                {
                    hfProductID.Value = product.ProductID.ToString();
                    txtProductName.Text = product.ProductName;
                    txtDescription.Text = product.Description;
                    txtPrice.Text = product.Price.ToString("N2");
                    txtStock.Text = product.StockQuantity.ToString();
                    ddlCategory.SelectedValue = product.CategoryID.ToString();
                    chkIsActive.Checked = product.IsActive;

                    if (!string.IsNullOrEmpty(product.ImageUrl))
                    {
                        pnlCurrentImage.Visible = true;
                        imgCurrent.ImageUrl = product.ImageUrl;
                        hfCurrentImage.Value = product.ImageUrl;
                    }
                    else
                    {
                        pnlCurrentImage.Visible = false;
                    }

                    lblFormTitle.Text = "✏️ Ürün Düzenle: " + product.ProductName;
                    btnSave.Text = "Güncelle";
                    pnlForm.Visible = true;
                }
            }
            catch (Exception ex)
            {
                ShowError("Ürün yüklenirken hata: " + ex.Message);
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            try
            {
                ProductRepo productRepo = new ProductRepo();
                
                // Fiyatı parse et
                decimal price = 0;
                decimal.TryParse(txtPrice.Text.Replace(",", "."), System.Globalization.NumberStyles.Any, 
                    System.Globalization.CultureInfo.InvariantCulture, out price);

                Product product = new Product
                {
                    ProductName = txtProductName.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    Price = price,
                    StockQuantity = Convert.ToInt32(txtStock.Text),
                    CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
                    IsActive = chkIsActive.Checked,
                    ImageUrl = hfCurrentImage.Value
                };

                // Görsel yükleme
                if (fuImage.HasFile)
                {
                    string imageUrl = SaveUploadedImage();
                    if (!string.IsNullOrEmpty(imageUrl))
                    {
                        product.ImageUrl = imageUrl;
                    }
                    else
                    {
                        return; // Hata mesajı zaten gösterildi
                    }
                }

                int productId = Convert.ToInt32(hfProductID.Value);

                if (productId > 0)
                {
                    product.ProductID = productId;
                    int result = productRepo.Update(product);
                    if (result > 0)
                    {
                        ShowSuccess("Ürün başarıyla güncellendi.");
                        ClearForm();
                        pnlForm.Visible = false;
                        LoadProducts();
                    }
                }
                else
                {
                    int newId = productRepo.Insert(product);
                    if (newId > 0)
                    {
                        ShowSuccess("Ürün başarıyla eklendi. (ID: " + newId + ")");
                        ClearForm();
                        pnlForm.Visible = false;
                        LoadProducts();
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Kaydetme hatası: " + ex.Message);
            }
        }

        private string SaveUploadedImage()
        {
            try
            {
                string extension = Path.GetExtension(fuImage.FileName).ToLower();
                
                // Uzantı kontrolü
                bool isValidExtension = false;
                foreach (string ext in allowedExtensions)
                {
                    if (ext == extension)
                    {
                        isValidExtension = true;
                        break;
                    }
                }

                if (!isValidExtension)
                {
                    ShowError("Geçersiz dosya formatı. Sadece JPG, PNG, GIF yüklenebilir.");
                    return null;
                }

                // Boyut kontrolü (5MB)
                if (fuImage.PostedFile.ContentLength > 5 * 1024 * 1024)
                {
                    ShowError("Dosya boyutu 5MB'dan büyük olamaz.");
                    return null;
                }

                // GUID ile benzersiz dosya adı
                string fileName = Guid.NewGuid().ToString() + extension;
                string uploadPath = Server.MapPath("~/Uploads/");

                if (!Directory.Exists(uploadPath))
                {
                    Directory.CreateDirectory(uploadPath);
                }

                string fullPath = Path.Combine(uploadPath, fileName);
                fuImage.SaveAs(fullPath);

                return "~/Uploads/" + fileName;
            }
            catch (Exception ex)
            {
                ShowError("Görsel yüklenirken hata: " + ex.Message);
                return null;
            }
        }

        protected void btnCancelForm_Click(object sender, EventArgs e)
        {
            ClearForm();
            pnlForm.Visible = false;
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            gvProducts.PageIndex = 0;
            LoadProducts();
        }

        private void ClearForm()
        {
            hfProductID.Value = "0";
            txtProductName.Text = "";
            txtDescription.Text = "";
            txtPrice.Text = "";
            txtStock.Text = "";
            ddlCategory.SelectedIndex = 0;
            chkIsActive.Checked = true;
            pnlCurrentImage.Visible = false;
            hfCurrentImage.Value = "";
            lblFormTitle.Text = "➕ Yeni Ürün Ekle";
            btnSave.Text = "Kaydet";
        }

        private void ShowSuccess(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-success";
            lblMessage.Text = message;
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}

