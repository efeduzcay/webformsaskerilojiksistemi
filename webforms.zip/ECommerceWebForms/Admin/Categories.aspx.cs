using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ECommerceWebForms.Admin
{
    public partial class CategoriesPage : BasePage
    {
        // Admin yetkisi gerekli
        protected override int RequiredRoleId { get { return 1; } }
        protected override bool RequiresLogin { get { return true; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCategories();
            }
        }

        private void LoadCategories(string searchKeyword = "")
        {
            try
            {
                CategoryRepo categoryRepo = new CategoryRepo();
                List<Category> categories;

                if (!string.IsNullOrEmpty(searchKeyword))
                {
                    categories = categoryRepo.Search(searchKeyword);
                }
                else
                {
                    categories = categoryRepo.GetAll();
                }

                // Sıralama uygula
                ApplySorting(ref categories);

                gvCategories.DataSource = categories;
                gvCategories.DataBind();
            }
            catch (Exception ex)
            {
                ShowError("Kategoriler yüklenirken hata: " + ex.Message);
            }
        }

        // Sıralama işlemi
        private string SortExpression
        {
            get { return ViewState["SortExpression"] as string ?? "CategoryName"; }
            set { ViewState["SortExpression"] = value; }
        }

        private string SortDirection
        {
            get { return ViewState["SortDirection"] as string ?? "ASC"; }
            set { ViewState["SortDirection"] = value; }
        }

        private void ApplySorting(ref List<Category> categories)
        {
            switch (SortExpression)
            {
                case "CategoryID":
                    categories.Sort((a, b) => SortDirection == "ASC" ? a.CategoryID.CompareTo(b.CategoryID) : b.CategoryID.CompareTo(a.CategoryID));
                    break;
                case "CategoryName":
                    categories.Sort((a, b) => SortDirection == "ASC" ? a.CategoryName.CompareTo(b.CategoryName) : b.CategoryName.CompareTo(a.CategoryName));
                    break;
                case "IsActive":
                    categories.Sort((a, b) => SortDirection == "ASC" ? a.IsActive.CompareTo(b.IsActive) : b.IsActive.CompareTo(a.IsActive));
                    break;
                case "CreatedDate":
                    categories.Sort((a, b) => SortDirection == "ASC" ? a.CreatedDate.CompareTo(b.CreatedDate) : b.CreatedDate.CompareTo(a.CreatedDate));
                    break;
            }
        }

        protected void gvCategories_Sorting(object sender, GridViewSortEventArgs e)
        {
            if (SortExpression == e.SortExpression)
            {
                SortDirection = SortDirection == "ASC" ? "DESC" : "ASC";
            }
            else
            {
                SortExpression = e.SortExpression;
                SortDirection = "ASC";
            }
            LoadCategories(txtSearch.Text.Trim());
        }

        protected void gvCategories_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvCategories.PageIndex = e.NewPageIndex;
            LoadCategories(txtSearch.Text.Trim());
        }

        protected void gvCategories_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "EditCategory")
            {
                int categoryId = Convert.ToInt32(e.CommandArgument);
                LoadCategoryForEdit(categoryId);
            }
        }

        protected void gvCategories_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            try
            {
                int categoryId = Convert.ToInt32(gvCategories.DataKeys[e.RowIndex].Value);
                CategoryRepo categoryRepo = new CategoryRepo();

                // Kategoriye bağlı ürün var mı kontrol et
                int productCount = categoryRepo.GetProductCount(categoryId);
                if (productCount > 0)
                {
                    ShowError("Bu kategoriye bağlı " + productCount + " ürün var. Önce ürünleri silmeniz veya başka kategoriye taşımanız gerekir.");
                    return;
                }

                int result = categoryRepo.Delete(categoryId);
                if (result > 0)
                {
                    ShowSuccess("Kategori başarıyla silindi.");
                    LoadCategories(txtSearch.Text.Trim());
                }
                else
                {
                    ShowError("Kategori silinemedi.");
                }
            }
            catch (Exception ex)
            {
                ShowError("Silme hatası: " + ex.Message);
            }
        }

        private void LoadCategoryForEdit(int categoryId)
        {
            try
            {
                CategoryRepo categoryRepo = new CategoryRepo();
                Category category = categoryRepo.GetById(categoryId);

                if (category != null)
                {
                    hfCategoryID.Value = category.CategoryID.ToString();
                    txtCategoryName.Text = category.CategoryName;
                    txtDescription.Text = category.Description;
                    chkIsActive.Checked = category.IsActive;

                    lblFormTitle.Text = "✏️ Kategori Düzenle: " + category.CategoryName;
                    btnSave.Text = "Güncelle";
                }
            }
            catch (Exception ex)
            {
                ShowError("Kategori yüklenirken hata: " + ex.Message);
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            try
            {
                CategoryRepo categoryRepo = new CategoryRepo();
                
                Category category = new Category
                {
                    CategoryName = txtCategoryName.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    IsActive = chkIsActive.Checked
                };

                int categoryId = Convert.ToInt32(hfCategoryID.Value);

                if (categoryId > 0)
                {
                    // Güncelleme
                    category.CategoryID = categoryId;
                    int result = categoryRepo.Update(category);
                    if (result > 0)
                    {
                        ShowSuccess("Kategori başarıyla güncellendi.");
                        ClearForm();
                        LoadCategories();
                    }
                    else
                    {
                        ShowError("Kategori güncellenemedi.");
                    }
                }
                else
                {
                    // Yeni ekleme
                    int newId = categoryRepo.Insert(category);
                    if (newId > 0)
                    {
                        ShowSuccess("Kategori başarıyla eklendi. (ID: " + newId + ")");
                        ClearForm();
                        LoadCategories();
                    }
                    else
                    {
                        ShowError("Kategori eklenemedi.");
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Kaydetme hatası: " + ex.Message);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            gvCategories.PageIndex = 0;
            LoadCategories(txtSearch.Text.Trim());
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            gvCategories.PageIndex = 0;
            LoadCategories();
        }

        private void ClearForm()
        {
            hfCategoryID.Value = "0";
            txtCategoryName.Text = "";
            txtDescription.Text = "";
            chkIsActive.Checked = true;
            lblFormTitle.Text = "➕ Yeni Kategori Ekle";
            btnSave.Text = "Kaydet";
        }

        private void ShowSuccess(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-success";
            lblMessage.Text = message;
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}

