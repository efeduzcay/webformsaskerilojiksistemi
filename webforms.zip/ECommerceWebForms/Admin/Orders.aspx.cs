using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ECommerceWebForms.Admin
{
    public partial class AdminOrdersPage : BasePage
    {
        protected override int RequiredRoleId { get { return 1; } }
        protected override bool RequiresLogin { get { return true; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadOrders();
            }
        }

        private void LoadOrders()
        {
            try
            {
                OrderRepo orderRepo = new OrderRepo();
                List<Order> orders = orderRepo.GetAll();

                // Durum filtresi
                string statusFilter = ddlStatus.SelectedValue;
                if (!string.IsNullOrEmpty(statusFilter))
                {
                    orders = orders.FindAll(o => o.Status == statusFilter);
                }

                gvOrders.DataSource = orders;
                gvOrders.DataBind();
            }
            catch (Exception ex)
            {
                ShowError("Siparişler yüklenirken hata: " + ex.Message);
            }
        }

        protected string GetStatusBadgeClass(string status)
        {
            switch (status)
            {
                case "Beklemede": return "badge-warning";
                case "Onaylandı": return "badge-info";
                case "Kargoda": return "badge-info";
                case "Teslim Edildi": return "badge-success";
                case "İptal": return "badge-danger";
                default: return "badge-secondary";
            }
        }

        protected void gvOrders_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvOrders.PageIndex = e.NewPageIndex;
            LoadOrders();
        }

        protected void gvOrders_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            int orderId = Convert.ToInt32(e.CommandArgument);

            if (e.CommandName == "UpdateStatus")
            {
                // GridView'da ilgili satırı bul
                GridViewRow row = (GridViewRow)((LinkButton)e.CommandSource).NamingContainer;
                DropDownList ddlNewStatus = (DropDownList)row.FindControl("ddlNewStatus");
                
                try
                {
                    OrderRepo orderRepo = new OrderRepo();
                    DateTime? deliveryDate = null;
                    if (ddlNewStatus.SelectedValue == "Teslim Edildi")
                    {
                        deliveryDate = DateTime.Now;
                    }

                    int result = orderRepo.UpdateStatus(orderId, ddlNewStatus.SelectedValue, deliveryDate);
                    if (result > 0)
                    {
                        ShowSuccess("Sipariş durumu güncellendi.");
                        LoadOrders();
                    }
                }
                catch (Exception ex)
                {
                    ShowError("Güncelleme hatası: " + ex.Message);
                }
            }
            else if (e.CommandName == "ViewDetail")
            {
                LoadOrderDetail(orderId);
            }
        }

        private void LoadOrderDetail(int orderId)
        {
            try
            {
                OrderRepo orderRepo = new OrderRepo();
                Order order = orderRepo.GetById(orderId);

                if (order != null)
                {
                    lblOrderId.Text = order.OrderID.ToString();
                    lblCustomerName.Text = order.CustomerName;
                    lblOrderDate.Text = order.OrderDate.ToString("dd.MM.yyyy HH:mm");
                    lblTotalAmount.Text = "₺" + order.TotalAmount.ToString("N2");
                    lblStatus.Text = order.Status;
                    lblAddress.Text = order.ShippingAddress;
                    lblNotes.Text = !string.IsNullOrEmpty(order.Notes) ? order.Notes : "-";

                    rptOrderDetails.DataSource = order.OrderDetails;
                    rptOrderDetails.DataBind();

                    pnlOrderDetail.Visible = true;
                }
            }
            catch (Exception ex)
            {
                ShowError("Detay yüklenirken hata: " + ex.Message);
            }
        }

        protected void btnCloseDetail_Click(object sender, EventArgs e)
        {
            pnlOrderDetail.Visible = false;
        }

        protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvOrders.PageIndex = 0;
            LoadOrders();
        }

        private void ShowSuccess(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-success";
            lblMessage.Text = message;
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}

