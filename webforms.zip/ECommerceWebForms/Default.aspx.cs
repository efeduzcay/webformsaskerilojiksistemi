using System;
using System.Collections.Generic;

namespace ECommerceWebForms
{
    public partial class DefaultPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCategories();
                LoadFeaturedProducts();
            }
        }

        private void LoadCategories()
        {
            try
            {
                CategoryRepo categoryRepo = new CategoryRepo();
                List<Category> categories = categoryRepo.GetActive();
                rptCategories.DataSource = categories;
                rptCategories.DataBind();
            }
            catch (Exception ex)
            {
                // Log error
            }
        }

        private void LoadFeaturedProducts()
        {
            try
            {
                ProductRepo productRepo = new ProductRepo();
                List<Product> products = productRepo.GetActive();
                
                // İlk 8 ürünü göster
                if (products.Count > 8)
                {
                    products = products.GetRange(0, 8);
                }
                
                rptProducts.DataSource = products;
                rptProducts.DataBind();
            }
            catch (Exception ex)
            {
                // Log error
            }
        }
    }
}

