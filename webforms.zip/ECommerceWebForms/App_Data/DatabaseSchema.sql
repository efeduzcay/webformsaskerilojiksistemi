-- =====================================================
-- E-Ticaret Veritabanı Şeması - MS Access (.mdb)
-- ASP.NET Web Forms Projesi için
-- =====================================================
-- NOT: Bu SQL scriptleri Access'te CREATE TABLE yerine
-- Access tasarım görünümünde tablo oluşturmanız gerekir.
-- Aşağıdaki yapıyı referans alın.
-- =====================================================

-- TABLO: Roles (Roller)
-- =====================================================
-- RoleID       : AutoNumber (Primary Key)
-- RoleName     : Text(50), NOT NULL
-- Description  : Text(255)

-- TABLO: Users (Kullanıcılar)
-- =====================================================
-- UserID       : AutoNumber (Primary Key)
-- Username     : Text(50), NOT NULL, UNIQUE
-- Email        : Text(100), NOT NULL
-- PasswordHash : Text(255), NOT NULL
-- PasswordSalt : Text(50), NOT NULL
-- FullName     : Text(100)
-- Phone        : Text(20)
-- Address      : Memo
-- RoleID       : Number (Long Integer), Foreign Key -> Roles
-- IsActive     : Yes/No, Default: True
-- CreatedDate  : Date/Time, Default: Now()

-- TABLO: Categories (Kategoriler)
-- =====================================================
-- CategoryID   : AutoNumber (Primary Key)
-- CategoryName : Text(100), NOT NULL
-- Description  : Text(500)
-- IsActive     : Yes/No, Default: True
-- CreatedDate  : Date/Time, Default: Now()

-- TABLO: Products (Ürünler)
-- =====================================================
-- ProductID    : AutoNumber (Primary Key)
-- ProductName  : Text(200), NOT NULL
-- Description  : Memo
-- Price        : Currency, NOT NULL
-- StockQuantity: Number (Long Integer), NOT NULL, Default: 0
-- CategoryID   : Number (Long Integer), Foreign Key -> Categories
-- ImageUrl     : Text(255)
-- IsActive     : Yes/No, Default: True
-- CreatedDate  : Date/Time, Default: Now()

-- TABLO: Orders (Siparişler)
-- =====================================================
-- OrderID      : AutoNumber (Primary Key)
-- UserID       : Number (Long Integer), Foreign Key -> Users
-- OrderDate    : Date/Time, Default: Now()
-- DeliveryDate : Date/Time
-- TotalAmount  : Currency, NOT NULL
-- Status       : Text(50), Default: "Beklemede"
-- ShippingAddress: Memo
-- Notes        : Memo

-- TABLO: OrderDetails (Sipariş Detayları)
-- =====================================================
-- OrderDetailID: AutoNumber (Primary Key)
-- OrderID      : Number (Long Integer), Foreign Key -> Orders
-- ProductID    : Number (Long Integer), Foreign Key -> Products
-- Quantity     : Number (Long Integer), NOT NULL
-- UnitPrice    : Currency, NOT NULL
-- TotalPrice   : Currency, NOT NULL

-- =====================================================
-- SEED DATA (Örnek Veriler)
-- =====================================================

-- Roller
INSERT INTO Roles (RoleName, Description) VALUES ('Admin', 'Sistem Yöneticisi');
INSERT INTO Roles (RoleName, Description) VALUES ('User', 'Normal Kullanıcı');

-- Kategoriler
INSERT INTO Categories (CategoryName, Description, IsActive, CreatedDate) VALUES ('Elektronik', 'Telefon, bilgisayar, tablet ve diğer elektronik ürünler', True, Now());
INSERT INTO Categories (CategoryName, Description, IsActive, CreatedDate) VALUES ('Giyim', 'Erkek, kadın ve çocuk giyim ürünleri', True, Now());
INSERT INTO Categories (CategoryName, Description, IsActive, CreatedDate) VALUES ('Ev & Yaşam', 'Ev dekorasyonu, mobilya ve yaşam ürünleri', True, Now());

-- Kullanıcılar (Şifreler: admin123 ve user123)
-- NOT: Hash değerleri PasswordHelper ile üretilmelidir
-- Aşağıdaki değerler placeholder'dır, çalıştırmadan önce güncelleyin
INSERT INTO Users (Username, Email, PasswordHash, PasswordSalt, FullName, Phone, Address, RoleID, IsActive, CreatedDate) 
VALUES ('admin', 'admin@eticaret.com', 'HASH_BURAYA', 'SALT_BURAYA', 'Sistem Yöneticisi', '0532 123 4567', 'İstanbul, Türkiye', 1, True, Now());

INSERT INTO Users (Username, Email, PasswordHash, PasswordSalt, FullName, Phone, Address, RoleID, IsActive, CreatedDate) 
VALUES ('user', 'user@eticaret.com', 'HASH_BURAYA', 'SALT_BURAYA', 'Test Kullanıcı', '0533 987 6543', 'Ankara, Türkiye', 2, True, Now());

-- Ürünler (10+ kayıt)
INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('iPhone 15 Pro', 'Apple iPhone 15 Pro 256GB Titanium', 64999.00, 25, 1, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('Samsung Galaxy S24', 'Samsung Galaxy S24 Ultra 512GB', 54999.00, 30, 1, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('MacBook Pro 14', 'Apple MacBook Pro 14 inç M3 Pro', 89999.00, 15, 1, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('Dell XPS 15', 'Dell XPS 15 Intel i7 32GB RAM', 49999.00, 20, 1, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('iPad Air', 'Apple iPad Air 5. Nesil 256GB', 29999.00, 35, 1, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('Erkek Deri Ceket', 'Hakiki deri erkek ceket, siyah', 2499.00, 50, 2, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('Kadın Trençkot', 'Klasik kesim kadın trençkot, bej', 1899.00, 40, 2, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('Spor Ayakkabı', 'Nike Air Max 270 unisex spor ayakkabı', 3299.00, 60, 2, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('Kot Pantolon', 'Slim fit erkek kot pantolon, mavi', 599.00, 100, 2, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('L Koltuk Takımı', 'Modern L koltuk takımı, gri kumaş', 24999.00, 10, 3, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('Yemek Masası Seti', '6 kişilik ahşap yemek masası ve sandalye seti', 12999.00, 15, 3, '', True, Now());

INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate)
VALUES ('LED TV 55 inç', 'Samsung 55 inç 4K Smart LED TV', 19999.00, 20, 1, '', True, Now());

-- Siparişler (Örnek)
INSERT INTO Orders (UserID, OrderDate, TotalAmount, Status, ShippingAddress, Notes)
VALUES (2, Now(), 67498.00, 'Teslim Edildi', 'Test Kullanıcı\n0533 987 6543\nAnkara, Türkiye', 'Hızlı teslimat lütfen');

INSERT INTO Orders (UserID, OrderDate, TotalAmount, Status, ShippingAddress, Notes)
VALUES (2, Now(), 2499.00, 'Beklemede', 'Test Kullanıcı\n0533 987 6543\nAnkara, Türkiye', '');

-- Sipariş Detayları
INSERT INTO OrderDetails (OrderID, ProductID, Quantity, UnitPrice, TotalPrice)
VALUES (1, 1, 1, 64999.00, 64999.00);

INSERT INTO OrderDetails (OrderID, ProductID, Quantity, UnitPrice, TotalPrice)
VALUES (1, 6, 1, 2499.00, 2499.00);

INSERT INTO OrderDetails (OrderID, ProductID, Quantity, UnitPrice, TotalPrice)
VALUES (2, 6, 1, 2499.00, 2499.00);
