# E-Ticaret Web Forms Projesi

ASP.NET Web Forms ile geliştirilmiş tam fonksiyonel e-ticaret dönem sonu projesi.

## 🚀 Kurulum Adımları

### Gereksinimler
- Visual Studio 2019/2022
- .NET Framework 4.7.2+
- Microsoft Access Database Engine (32-bit veya 64-bit)

### Adım 1: Projeyi Açma
1. `ECommerceWebForms` klasörünü Visual Studio ile açın
2. Solution Explorer'da projeyi sağ tıklayın → "Build" yapın

### Adım 2: Veritabanı Oluşturma
1. Microsoft Access'i açın
2. Yeni bir boş veritabanı oluşturun: `ECommerce.mdb`
3. `App_Data\DatabaseSchema.sql` dosyasındaki tabloları Access'te oluşturun:
   - **Roles** tablosu
   - **Users** tablosu
   - **Categories** tablosu
   - **Products** tablosu
   - **Orders** tablosu
   - **OrderDetails** tablosu
4. SQL dosyasındaki INSERT sorgularını çalıştırarak örnek verileri ekleyin
5. Veritabanını `App_Data` klasörüne kaydedin

### Adım 3: Kullanıcı Şifrelerini Oluşturma
Hash+Salt şifreleri oluşturmak için aşağıdaki C# kodunu kullanın:

```csharp
string salt = PasswordHelper.GenerateSalt();
string hash = PasswordHelper.HashPassword("admin123", salt);
// Users tablosuna bu hash ve salt değerlerini girin
```

### Adım 4: Çalıştırma
1. F5 tuşuna basarak projeyi çalıştırın
2. Tarayıcıda `http://localhost:xxxx/Default.aspx` açılacaktır

## 🔐 Test Kullanıcıları

| Kullanıcı | Şifre     | Rol    |
|-----------|-----------|--------|
| admin     | admin123  | Admin  |
| user      | user123   | User   |

## 📁 Proje Yapısı

```
ECommerceWebForms/
├── App_Code/
│   ├── Data/
│   │   └── Db.cs              # Veritabanı bağlantı helper
│   ├── Helpers/
│   │   ├── BasePage.cs        # Sayfa base sınıfı
│   │   └── PasswordHelper.cs  # Hash+Salt şifreleme
│   ├── Models/
│   │   ├── Product.cs
│   │   ├── Category.cs
│   │   ├── User.cs
│   │   ├── Role.cs
│   │   ├── Order.cs
│   │   ├── OrderDetail.cs
│   │   └── CartItem.cs
│   └── Repositories/
│       ├── ProductRepo.cs
│       ├── CategoryRepo.cs
│       ├── UserRepo.cs
│       ├── OrderRepo.cs
│       └── RoleRepo.cs
├── Admin/
│   ├── Default.aspx           # Admin Dashboard
│   ├── Categories.aspx        # Kategori CRUD
│   ├── Products.aspx          # Ürün CRUD + FileUpload
│   ├── Orders.aspx            # Sipariş yönetimi
│   └── Users.aspx             # Kullanıcı yönetimi
├── User/
│   ├── Cart.aspx              # Sepet (Session tabanlı)
│   ├── Checkout.aspx          # Sipariş oluşturma
│   ├── Orders.aspx            # Siparişlerim
│   └── Profile.aspx           # Profil düzenleme
├── Content/
│   └── Site.css               # Ana stil dosyası
├── Uploads/                   # Ürün görselleri
├── App_Data/
│   ├── ECommerce.mdb          # Access veritabanı
│   └── DatabaseSchema.sql     # Şema ve seed data
├── Site.Master                # Master Page
├── Default.aspx               # Ana sayfa
├── Products.aspx              # Ürün listesi
├── ProductDetail.aspx         # Ürün detay
├── Login.aspx                 # Giriş
├── Register.aspx              # Kayıt
├── AccessDenied.aspx          # Erişim engeli
├── Web.config                 # Yapılandırma
└── Global.asax                # Uygulama olayları
```

## ✅ Özellikler

### Genel
- Master Page temelli tutarlı tasarım
- Modern, responsive CSS (Gradient, animasyonlar)
- Dinamik menü (rol bazlı)
- Session tabanlı sepet

### Public Alan
- Ana sayfa (kategoriler + öne çıkan ürünler)
- Ürün listesi (arama, filtreleme, sıralama)
- Ürün detay sayfası
- Kayıt ve giriş

### Kullanıcı Paneli
- Profil düzenleme
- Sepet yönetimi (AJAX UpdatePanel)
- Sipariş oluşturma (Calendar kontrolü)
- Sipariş geçmişi

### Admin Paneli
- Dashboard (istatistikler)
- Kategori CRUD (GridView sorting/paging)
- Ürün CRUD (FileUpload ile görsel)
- Sipariş yönetimi (durum güncelleme)
- Kullanıcı yönetimi (rol atama)

### Güvenlik
- Parametreli sorgular (SQL Injection koruması)
- Hash+Salt şifreleme (SHA256)
- Rol bazlı yetkilendirme
- Güvenli FileUpload (uzantı + boyut kontrolü)

## 🎛️ Kullanılan WebForms Kontrolleri

1. GridView (sorting, paging, edit, delete)
2. FormView / DetailsView
3. Repeater
4. DropDownList
5. TextBox
6. Button / LinkButton
7. Label
8. RequiredFieldValidator
9. RegularExpressionValidator
10. CompareValidator
11. ValidationSummary
12. Menu
13. LoginView
14. FileUpload
15. Calendar
16. UpdatePanel (AJAX)
17. ScriptManager
18. Panel
19. HiddenField
20. CheckBox

## 📝 Notlar

- Access veritabanı 32-bit/64-bit uyumluluğuna dikkat edin
- Visual Studio'da "Build" hatası alırsanız IIS Express'i yeniden başlatın
- Uploads klasörüne yazma yetkisi verildiğinden emin olun
