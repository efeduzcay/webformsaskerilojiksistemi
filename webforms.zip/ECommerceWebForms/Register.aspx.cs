using System;

namespace ECommerceWebForms
{
    public partial class RegisterPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Zaten giriş yapmışsa ana sayfaya yönlendir
            if (Session["UserID"] != null)
            {
                Response.Redirect("~/Default.aspx");
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            try
            {
                UserRepo userRepo = new UserRepo();

                // Kullanıcı adı kontrolü
                if (userRepo.UsernameExists(txtUsername.Text.Trim()))
                {
                    ShowError("Bu kullanıcı adı zaten kullanılıyor.");
                    return;
                }

                // Email kontrolü
                if (userRepo.EmailExists(txtEmail.Text.Trim()))
                {
                    ShowError("Bu e-posta adresi zaten kayıtlı.");
                    return;
                }

                // Yeni kullanıcı oluştur
                UserModel UserModel = new UserModel
                {
                    Username = txtUsername.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    FullName = txtFullName.Text.Trim(),
                    Phone = txtPhone.Text.Trim(),
                    Address = txtAddress.Text.Trim(),
                    RoleID = 2, // UserModel rolü
                    IsActive = true
                };

                int userId = userRepo.Insert(UserModel, txtPassword.Text);

                if (userId > 0)
                {
                    ShowSuccess("Kayıt başarılı! Giriş sayfasına yönlendiriliyorsunuz...");
                    
                    // 2 saniye sonra login sayfasına yönlendir
                    Response.AddHeader("REFRESH", "2;URL=Login.aspx");
                }
                else
                {
                    ShowError("Kayıt sırasında bir hata oluştu.");
                }
            }
            catch (Exception ex)
            {
                ShowError("Kayıt sırasında bir hata oluştu: " + ex.Message);
            }
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }

        private void ShowSuccess(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-success";
            lblMessage.Text = message;
        }
    }
}

