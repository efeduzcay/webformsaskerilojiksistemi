using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ECommerceWebForms.User
{
    public partial class UserOrdersPage : BasePage
    {
        protected override bool RequiresLogin { get { return true; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadOrders();
            }
        }

        private void LoadOrders()
        {
            try
            {
                OrderRepo orderRepo = new OrderRepo();
                List<Order> orders = orderRepo.GetByUserId(CurrentUserId);

                gvOrders.DataSource = orders;
                gvOrders.DataBind();
            }
            catch (Exception ex)
            {
                // Hata
            }
        }

        protected string GetStatusBadgeClass(string status)
        {
            switch (status)
            {
                case "Beklemede": return "badge-warning";
                case "Onaylandı": return "badge-info";
                case "Kargoda": return "badge-info";
                case "Teslim Edildi": return "badge-success";
                case "İptal": return "badge-danger";
                default: return "badge-secondary";
            }
        }

        protected void gvOrders_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvOrders.PageIndex = e.NewPageIndex;
            LoadOrders();
        }

        protected void gvOrders_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ViewDetail")
            {
                int orderId = Convert.ToInt32(e.CommandArgument);
                LoadOrderDetail(orderId);
            }
        }

        private void LoadOrderDetail(int orderId)
        {
            try
            {
                OrderRepo orderRepo = new OrderRepo();
                Order order = orderRepo.GetById(orderId);

                // Güvenlik: sadece kendi siparişi
                if (order == null || order.UserID != CurrentUserId)
                {
                    return;
                }

                lblOrderId.Text = order.OrderID.ToString();
                lblOrderDate.Text = order.OrderDate.ToString("dd.MM.yyyy HH:mm");
                lblStatus.Text = order.Status;
                lblAddress.Text = order.ShippingAddress.Replace("\n", "<br/>");
                lblTotalAmount.Text = order.TotalAmount.ToString("N2");

                rptOrderDetails.DataSource = order.OrderDetails;
                rptOrderDetails.DataBind();

                pnlOrderDetail.Visible = true;
            }
            catch (Exception ex)
            {
                // Hata
            }
        }

        protected void btnCloseDetail_Click(object sender, EventArgs e)
        {
            pnlOrderDetail.Visible = false;
        }
    }
}


