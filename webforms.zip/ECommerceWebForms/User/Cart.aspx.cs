using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ECommerceWebForms.User
{
    public partial class CartPage : BasePage
    {
        protected override bool RequiresLogin { get { return true; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCart();
            }
        }

        private void LoadCart()
        {
            List<CartItem> cart = Session["Cart"] as List<CartItem>;

            if (cart == null || cart.Count == 0)
            {
                pnlCart.Visible = false;
                pnlEmpty.Visible = true;
                return;
            }

            pnlCart.Visible = true;
            pnlEmpty.Visible = false;

            rptCart.DataSource = cart;
            rptCart.DataBind();

            // Toplam hesapla
            decimal total = 0;
            foreach (CartItem item in cart)
            {
                total += item.TotalPrice;
            }
            lblTotal.Text = total.ToString("N2");
        }

        protected void rptCart_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            int productId = Convert.ToInt32(e.CommandArgument);
            List<CartItem> cart = Session["Cart"] as List<CartItem>;

            if (cart == null) return;

            CartItem item = cart.Find(x => x.ProductID == productId);
            if (item == null) return;

            switch (e.CommandName)
            {
                case "Increase":
                    // Stok kontrolü
                    ProductRepo productRepo = new ProductRepo();
                    Product product = productRepo.GetById(productId);
                    if (product != null && item.Quantity < product.StockQuantity)
                    {
                        item.Quantity++;
                    }
                    else
                    {
                        ShowError("Yeterli stok yok!");
                    }
                    break;

                case "Decrease":
                    if (item.Quantity > 1)
                    {
                        item.Quantity--;
                    }
                    else
                    {
                        cart.Remove(item);
                    }
                    break;

                case "Remove":
                    cart.Remove(item);
                    break;
            }

            Session["Cart"] = cart;
            LoadCart();
        }

        protected void btnClearCart_Click(object sender, EventArgs e)
        {
            Session["Cart"] = new List<CartItem>();
            LoadCart();
            ShowSuccess("Sepet temizlendi.");
        }

        protected void btnCheckout_Click(object sender, EventArgs e)
        {
            Response.Redirect("Checkout.aspx");
        }

        private void ShowSuccess(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-success";
            lblMessage.Text = message;
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}


