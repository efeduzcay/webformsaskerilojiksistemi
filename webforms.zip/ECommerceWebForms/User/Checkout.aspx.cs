using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ECommerceWebForms.User
{
    public partial class CheckoutPage : BasePage
    {
        protected override bool RequiresLogin { get { return true; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Sepet boşsa sepete yönlendir
                List<CartItem> cart = Session["Cart"] as List<CartItem>;
                if (cart == null || cart.Count == 0)
                {
                    Response.Redirect("Cart.aspx");
                    return;
                }

                LoadUserInfo();
                LoadOrderSummary();
                
                // Varsayılan tarih: yarın
                calDelivery.SelectedDate = DateTime.Today.AddDays(1);
                lblSelectedDate.Text = calDelivery.SelectedDate.ToString("dd.MM.yyyy");
            }
        }

        private void LoadUserInfo()
        {
            try
            {
                int userId = CurrentUserId;
                UserRepo userRepo = new UserRepo();
                ECommerceWebForms.UserModel UserModel = userRepo.GetById(userId);

                if (UserModel != null)
                {
                    txtFullName.Text = UserModel.FullName;
                    txtPhone.Text = UserModel.Phone;
                    txtAddress.Text = UserModel.Address;
                }
            }
            catch (Exception ex)
            {
                // Hata durumunda formu boş bırak
            }
        }

        private void LoadOrderSummary()
        {
            List<CartItem> cart = Session["Cart"] as List<CartItem>;
            if (cart == null) return;

            rptSummary.DataSource = cart;
            rptSummary.DataBind();

            decimal total = 0;
            foreach (CartItem item in cart)
            {
                total += item.TotalPrice;
            }
            lblTotal.Text = total.ToString("N2");
        }

        protected void calDelivery_DayRender(object sender, DayRenderEventArgs e)
        {
            // Geçmiş tarihleri devre dışı bırak
            if (e.Day.Date < DateTime.Today)
            {
                e.Day.IsSelectable = false;
                e.Cell.ForeColor = System.Drawing.Color.Gray;
            }
        }

        protected void calDelivery_SelectionChanged(object sender, EventArgs e)
        {
            lblSelectedDate.Text = calDelivery.SelectedDate.ToString("dd.MM.yyyy");
        }

        protected void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            try
            {
                List<CartItem> cart = Session["Cart"] as List<CartItem>;
                if (cart == null || cart.Count == 0)
                {
                    ShowError("Sepetiniz boş!");
                    return;
                }

                // Stok kontrolü
                ProductRepo productRepo = new ProductRepo();
                foreach (CartItem item in cart)
                {
                    Product product = productRepo.GetById(item.ProductID);
                    if (product == null || product.StockQuantity < item.Quantity)
                    {
                        ShowError(item.ProductName + " için yeterli stok yok!");
                        return;
                    }
                }

                // Toplam hesapla
                decimal total = 0;
                foreach (CartItem item in cart)
                {
                    total += item.TotalPrice;
                }

                // Sipariş oluştur
                Order order = new Order
                {
                    UserID = CurrentUserId,
                    TotalAmount = total,
                    ShippingAddress = txtFullName.Text.Trim() + "\n" + txtPhone.Text.Trim() + "\n" + txtAddress.Text.Trim(),
                    Notes = txtNotes.Text.Trim()
                };

                if (calDelivery.SelectedDate > DateTime.Today)
                {
                    order.DeliveryDate = calDelivery.SelectedDate;
                }

                OrderRepo orderRepo = new OrderRepo();
                int orderId = orderRepo.CreateOrder(order, cart);

                if (orderId > 0)
                {
                    // Sepeti temizle
                    Session["Cart"] = new List<CartItem>();

                    // Başarı ekranını göster
                    pnlCheckout.Visible = false;
                    pnlSuccess.Visible = true;
                    lblOrderId.Text = orderId.ToString();
                }
                else
                {
                    ShowError("Sipariş oluşturulurken bir hata oluştu.");
                }
            }
            catch (Exception ex)
            {
                ShowError("Sipariş hatası: " + ex.Message);
            }
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}


