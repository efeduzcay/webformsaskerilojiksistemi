using System;

namespace ECommerceWebForms.User
{
    public partial class ProfilePage : BasePage
    {
        protected override bool RequiresLogin { get { return true; } }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadProfile();
            }
        }

        private void LoadProfile()
        {
            try
            {
                UserRepo userRepo = new UserRepo();
                ECommerceWebForms.UserModel UserModel = userRepo.GetById(CurrentUserId);

                if (UserModel != null)
                {
                    txtUsername.Text = UserModel.Username;
                    txtEmail.Text = UserModel.Email;
                    txtFullName.Text = UserModel.FullName;
                    txtPhone.Text = UserModel.Phone;
                    txtAddress.Text = UserModel.Address;
                }
            }
            catch (Exception ex)
            {
                ShowError("Profil yüklenirken hata: " + ex.Message);
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            try
            {
                UserRepo userRepo = new UserRepo();
                
                ECommerceWebForms.UserModel UserModel = new ECommerceWebForms.UserModel
                {
                    UserID = CurrentUserId,
                    Email = txtEmail.Text.Trim(),
                    FullName = txtFullName.Text.Trim(),
                    Phone = txtPhone.Text.Trim(),
                    Address = txtAddress.Text.Trim()
                };

                int result = userRepo.Update(UserModel);
                if (result > 0)
                {
                    // Session'ı güncelle
                    Session["FullName"] = UserModel.FullName;
                    ShowSuccess("Profil bilgileriniz güncellendi.");
                }
                else
                {
                    ShowError("Güncelleme yapılamadı.");
                }
            }
            catch (Exception ex)
            {
                ShowError("Hata: " + ex.Message);
            }
        }

        protected void btnChangePassword_Click(object sender, EventArgs e)
        {
            try
            {
                string currentPassword = txtCurrentPassword.Text;
                string newPassword = txtNewPassword.Text;
                string confirmPassword = txtNewPasswordConfirm.Text;

                // Validasyonlar
                if (string.IsNullOrEmpty(currentPassword) || string.IsNullOrEmpty(newPassword))
                {
                    ShowError("Mevcut şifre ve yeni şifre gereklidir.");
                    return;
                }

                if (newPassword.Length < 6)
                {
                    ShowError("Yeni şifre en az 6 karakter olmalıdır.");
                    return;
                }

                if (newPassword != confirmPassword)
                {
                    ShowError("Yeni şifreler eşleşmiyor.");
                    return;
                }

                // Mevcut şifre kontrolü
                UserRepo userRepo = new UserRepo();
                ECommerceWebForms.UserModel UserModel = userRepo.GetById(CurrentUserId);

                if (UserModel == null)
                {
                    ShowError("Kullanıcı bulunamadı.");
                    return;
                }

                if (!PasswordHelper.VerifyPassword(currentPassword, UserModel.PasswordHash, UserModel.PasswordSalt))
                {
                    ShowError("Mevcut şifre hatalı.");
                    return;
                }

                // Şifre değiştir
                int result = userRepo.ChangePassword(CurrentUserId, newPassword);
                if (result > 0)
                {
                    ShowSuccess("Şifreniz başarıyla değiştirildi.");
                    txtCurrentPassword.Text = "";
                    txtNewPassword.Text = "";
                    txtNewPasswordConfirm.Text = "";
                }
                else
                {
                    ShowError("Şifre değiştirilemedi.");
                }
            }
            catch (Exception ex)
            {
                ShowError("Şifre değiştirme hatası: " + ex.Message);
            }
        }

        private void ShowSuccess(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-success";
            lblMessage.Text = message;
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}


