using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ECommerceWebForms
{
    public partial class ProductsPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadCategories();
                
                // URL'den kategori ID al
                if (Request.QueryString["categoryId"] != null)
                {
                    ddlCategory.SelectedValue = Request.QueryString["categoryId"];
                }
                
                LoadProducts();
            }
        }

        private void LoadCategories()
        {
            try
            {
                CategoryRepo categoryRepo = new CategoryRepo();
                List<Category> categories = categoryRepo.GetActive();

                foreach (Category cat in categories)
                {
                    ddlCategory.Items.Add(new ListItem(cat.CategoryName, cat.CategoryID.ToString()));
                }
            }
            catch (Exception ex)
            {
                // Log error
            }
        }

        private void LoadProducts()
        {
            try
            {
                ProductRepo productRepo = new ProductRepo();
                List<Product> products;

                string keyword = txtSearch.Text.Trim();
                int categoryId = Convert.ToInt32(ddlCategory.SelectedValue);

                if (!string.IsNullOrEmpty(keyword))
                {
                    products = productRepo.Search(keyword, categoryId > 0 ? categoryId : (int?)null);
                    lblResult.Text = products.Count + " ürün bulundu.";
                    lblResult.Visible = true;
                }
                else if (categoryId > 0)
                {
                    products = productRepo.GetByCategory(categoryId);
                    lblResult.Text = ddlCategory.SelectedItem.Text + " kategorisinde " + products.Count + " ürün.";
                    lblResult.Visible = true;
                }
                else
                {
                    products = productRepo.GetActive();
                    lblResult.Visible = false;
                }

                // Sıralama
                string sortBy = ddlSort.SelectedValue;
                switch (sortBy)
                {
                    case "price_asc":
                        products.Sort((a, b) => a.Price.CompareTo(b.Price));
                        break;
                    case "price_desc":
                        products.Sort((a, b) => b.Price.CompareTo(a.Price));
                        break;
                    case "newest":
                        products.Sort((a, b) => b.CreatedDate.CompareTo(a.CreatedDate));
                        break;
                    default: // name
                        products.Sort((a, b) => a.ProductName.CompareTo(b.ProductName));
                        break;
                }

                rptProducts.DataSource = products;
                rptProducts.DataBind();
            }
            catch (Exception ex)
            {
                lblResult.CssClass = "alert alert-danger";
                lblResult.Text = "Ürünler yüklenirken hata: " + ex.Message;
                lblResult.Visible = true;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            LoadProducts();
        }

        protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadProducts();
        }

        protected void ddlSort_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadProducts();
        }

        protected void btnAddCart_Click(object sender, EventArgs e)
        {
            if (Session["UserID"] == null)
            {
                Response.Redirect("~/Login.aspx?returnUrl=" + Server.UrlEncode(Request.Url.PathAndQuery));
                return;
            }

            try
            {
                LinkButton btn = (LinkButton)sender;
                int productId = Convert.ToInt32(btn.CommandArgument);

                ProductRepo productRepo = new ProductRepo();
                Product product = productRepo.GetById(productId);

                if (product != null)
                {
                    List<CartItem> cart = Session["Cart"] as List<CartItem>;
                    if (cart == null)
                    {
                        cart = new List<CartItem>();
                    }

                    // Sepette var mı kontrol et
                    CartItem existingItem = cart.Find(x => x.ProductID == productId);
                    if (existingItem != null)
                    {
                        existingItem.Quantity++;
                    }
                    else
                    {
                        cart.Add(new CartItem
                        {
                            ProductID = product.ProductID,
                            ProductName = product.ProductName,
                            UnitPrice = product.Price,
                            Quantity = 1,
                            ImageUrl = product.ImageUrl
                        });
                    }

                    Session["Cart"] = cart;
                    
                    lblResult.CssClass = "alert alert-success";
                    lblResult.Text = product.ProductName + " sepete eklendi!";
                    lblResult.Visible = true;
                }
            }
            catch (Exception ex)
            {
                lblResult.CssClass = "alert alert-danger";
                lblResult.Text = "Sepete eklenirken hata: " + ex.Message;
                lblResult.Visible = true;
            }
        }
    }
}

