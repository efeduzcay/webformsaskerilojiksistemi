using System;
using System.Security.Cryptography;
using System.Text;

namespace ECommerceWebForms
{
    /// <summary>
    /// Şifre güvenliği için Hash + Salt yardımcı sınıfı
    /// SHA256 algoritması kullanılır
    /// </summary>
    public static class PasswordHelper
    {
        /// <summary>
        /// Rastgele salt oluşturur (16 byte = 128 bit)
        /// </summary>
        public static string GenerateSalt()
        {
            byte[] saltBytes = new byte[16];
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(saltBytes);
            }
            return Convert.ToBase64String(saltBytes);
        }

        /// <summary>
        /// Şifreyi salt ile birleştirip SHA256 hash'ler
        /// </summary>
        public static string HashPassword(string password, string salt)
        {
            string combined = password + salt;
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(combined);
                byte[] hashBytes = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hashBytes);
            }
        }

        /// <summary>
        /// Şifre doğrulama - kullanıcının girdiği şifre ile veritabanındaki hash karşılaştırılır
        /// </summary>
        public static bool VerifyPassword(string inputPassword, string storedHash, string storedSalt)
        {
            string hashOfInput = HashPassword(inputPassword, storedSalt);
            return hashOfInput == storedHash;
        }
    }
}

