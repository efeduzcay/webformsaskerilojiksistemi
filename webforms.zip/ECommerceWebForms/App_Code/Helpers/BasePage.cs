using System;
using System.Web;
using System.Web.UI;

namespace ECommerceWebForms
{
    /// <summary>
    /// Tüm sayfalar için temel sınıf
    /// Yetkilendirme ve ortak işlemler burada
    /// </summary>
    public class BasePage : Page
    {
        /// <summary>
        /// Sayfa için gereken minimum rol (override edilebilir)
        /// 0 = Anonim, 1 = Admin, 2 = UserModel
        /// </summary>
        protected virtual int RequiredRoleId { get { return 0; } }

        /// <summary>
        /// Login gerekli mi (override edilebilir)
        /// </summary>
        protected virtual bool RequiresLogin { get { return false; } }

        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);

            // Login kontrolü
            if (RequiresLogin && !IsLoggedIn)
            {
                Response.Redirect("~/Login.aspx?returnUrl=" + Server.UrlEncode(Request.Url.PathAndQuery));
                return;
            }

            // Rol kontrolü
            if (RequiredRoleId > 0 && CurrentUserRoleId != RequiredRoleId)
            {
                Response.Redirect("~/AccessDenied.aspx");
                return;
            }
        }

        /// <summary>
        /// Kullanıcı giriş yapmış mı
        /// </summary>
        public bool IsLoggedIn
        {
            get { return Session["UserID"] != null; }
        }

        /// <summary>
        /// Giriş yapan kullanıcının ID'si
        /// </summary>
        public int CurrentUserId
        {
            get
            {
                if (Session["UserID"] != null)
                {
                    return Convert.ToInt32(Session["UserID"]);
                }
                return 0;
            }
        }

        /// <summary>
        /// Giriş yapan kullanıcının rol ID'si
        /// </summary>
        public int CurrentUserRoleId
        {
            get
            {
                if (Session["RoleID"] != null)
                {
                    return Convert.ToInt32(Session["RoleID"]);
                }
                return 0;
            }
        }

        /// <summary>
        /// Giriş yapan kullanıcının kullanıcı adı
        /// </summary>
        public string CurrentUsername
        {
            get
            {
                if (Session["Username"] != null)
                {
                    return Session["Username"].ToString();
                }
                return "";
            }
        }

        /// <summary>
        /// Giriş yapan kullanıcının tam adı
        /// </summary>
        public string CurrentUserFullName
        {
            get
            {
                if (Session["FullName"] != null)
                {
                    return Session["FullName"].ToString();
                }
                return "";
            }
        }

        /// <summary>
        /// Kullanıcı Admin mi
        /// </summary>
        public bool IsAdmin
        {
            get { return CurrentUserRoleId == 1; }
        }

        /// <summary>
        /// Başarı mesajı göster
        /// </summary>
        protected void ShowSuccess(System.Web.UI.WebControls.Label label, string message)
        {
            label.CssClass = "alert alert-success";
            label.Text = message;
            label.Visible = true;
        }

        /// <summary>
        /// Hata mesajı göster
        /// </summary>
        protected void ShowError(System.Web.UI.WebControls.Label label, string message)
        {
            label.CssClass = "alert alert-danger";
            label.Text = message;
            label.Visible = true;
        }

        /// <summary>
        /// Bilgi mesajı göster
        /// </summary>
        protected void ShowInfo(System.Web.UI.WebControls.Label label, string message)
        {
            label.CssClass = "alert alert-info";
            label.Text = message;
            label.Visible = true;
        }
    }
}

