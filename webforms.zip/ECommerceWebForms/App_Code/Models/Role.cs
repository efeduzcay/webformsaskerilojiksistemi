using System;

namespace ECommerceWebForms
{
    /// <summary>
    /// Rol entity sınıfı
    /// </summary>
    [Serializable]
    public class Role
    {
        public int RoleID { get; set; }
        public string RoleName { get; set; }
        public string Description { get; set; }
    }
}

