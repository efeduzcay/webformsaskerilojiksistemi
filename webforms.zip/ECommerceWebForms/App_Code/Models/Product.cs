using System;

namespace ECommerceWebForms
{
    /// <summary>
    /// Ürün entity sınıfı
    /// </summary>
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public int CategoryID { get; set; }
        public string ImageUrl { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }

        // Navigation property (manual join ile doldurulacak)
        public string CategoryName { get; set; }
    }
}

