using System;

namespace ECommerceWebForms
{
    /// <summary>
    /// Sepet öğesi - Session'da tutulacak
    /// </summary>
    [Serializable]
    public class CartItem
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public string ImageUrl { get; set; }

        public decimal TotalPrice
        {
            get { return UnitPrice * Quantity; }
        }
    }
}

