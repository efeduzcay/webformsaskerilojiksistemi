using System;
using System.Collections.Generic;

namespace ECommerceWebForms
{
    /// <summary>
    /// Sipariş entity sınıfı
    /// </summary>
    public class Order
    {
        public int OrderID { get; set; }
        public int UserID { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public decimal TotalAmount { get; set; }
        public string Status { get; set; } // Beklemede, Onaylandı, Kargoda, Teslim Edildi, İptal
        public string ShippingAddress { get; set; }
        public string Notes { get; set; }

        // Navigation properties
        public string CustomerName { get; set; }
        public List<OrderDetail> OrderDetails { get; set; }

        public Order()
        {
            OrderDetails = new List<OrderDetail>();
        }
    }
}

