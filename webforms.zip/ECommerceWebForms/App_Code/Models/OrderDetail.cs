using System;

namespace ECommerceWebForms
{
    /// <summary>
    /// Sipariş detay entity sınıfı
    /// </summary>
    public class OrderDetail
    {
        public int OrderDetailID { get; set; }
        public int OrderID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }

        // Navigation properties
        public string ProductName { get; set; }
        public string ProductImage { get; set; }
    }
}

