using System;

namespace ECommerceWebForms
{
    /// <summary>
    /// Kategori entity sınıfı
    /// </summary>
    public class Category
    {
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedDate { get; set; }
        
        // İstatistik için
        public int ProductCount { get; set; }
    }
}

