using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;

namespace ECommerceWebForms
{
    /// <summary>
    /// Veritabanı bağlantı ve sorgu yardımcı sınıfı
    /// OleDb ile parametreli sorgular - SQL Injection koruması
    /// </summary>
    public static class Db
    {
        private static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["ECommerceDB"].ConnectionString;
            }
        }

        /// <summary>
        /// Yeni bir OleDbConnection döndürür
        /// </summary>
        public static OleDbConnection GetConnection()
        {
            return new OleDbConnection(ConnectionString);
        }

        /// <summary>
        /// SELECT sorgusu çalıştırır ve DataTable döndürür
        /// </summary>
        public static DataTable ExecuteQuery(string sql, params OleDbParameter[] parameters)
        {
            DataTable dt = new DataTable();
            using (OleDbConnection conn = GetConnection())
            {
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                    {
                        conn.Open();
                        adapter.Fill(dt);
                    }
                }
            }
            return dt;
        }

        /// <summary>
        /// INSERT, UPDATE, DELETE sorgusu çalıştırır
        /// Etkilenen satır sayısını döndürür
        /// </summary>
        public static int ExecuteNonQuery(string sql, params OleDbParameter[] parameters)
        {
            using (OleDbConnection conn = GetConnection())
            {
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    conn.Open();
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Tek değer döndüren sorgu çalıştırır (COUNT, MAX, vb.)
        /// </summary>
        public static object ExecuteScalar(string sql, params OleDbParameter[] parameters)
        {
            using (OleDbConnection conn = GetConnection())
            {
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    conn.Open();
                    return cmd.ExecuteScalar();
                }
            }
        }

        /// <summary>
        /// INSERT sonrası oluşan Identity (AutoNumber) değerini döndürür
        /// Access için @@IDENTITY kullanılır
        /// </summary>
        public static int ExecuteInsertAndGetId(string sql, params OleDbParameter[] parameters)
        {
            using (OleDbConnection conn = GetConnection())
            {
                conn.Open();
                using (OleDbCommand cmd = new OleDbCommand(sql, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    cmd.ExecuteNonQuery();

                    // Access'te @@IDENTITY ile son eklenen ID'yi al
                    cmd.CommandText = "SELECT @@IDENTITY";
                    cmd.Parameters.Clear();
                    object result = cmd.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
        }

        /// <summary>
        /// OleDbParameter oluşturma yardımcısı
        /// </summary>
        public static OleDbParameter CreateParameter(string name, object value)
        {
            return new OleDbParameter(name, value ?? DBNull.Value);
        }

        /// <summary>
        /// OleDbParameter oluşturma yardımcısı (tip belirtilerek)
        /// </summary>
        public static OleDbParameter CreateParameter(string name, OleDbType type, object value)
        {
            OleDbParameter param = new OleDbParameter(name, type);
            param.Value = value ?? DBNull.Value;
            return param;
        }
    }
}

