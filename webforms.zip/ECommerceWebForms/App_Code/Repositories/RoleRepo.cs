using System;
using System.Collections.Generic;
using System.Data;

namespace ECommerceWebForms
{
    /// <summary>
    /// Rol CRUD işlemleri
    /// </summary>
    public class RoleRepo
    {
        /// <summary>
        /// Tüm rolleri getirir
        /// </summary>
        public List<Role> GetAll()
        {
            string sql = "SELECT * FROM Roles ORDER BY RoleName";
            DataTable dt = Db.ExecuteQuery(sql);
            return MapToList(dt);
        }

        /// <summary>
        /// ID ile rol getirir
        /// </summary>
        public Role GetById(int roleId)
        {
            string sql = "SELECT * FROM Roles WHERE RoleID = ?";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@RoleID", roleId));
            if (dt.Rows.Count > 0)
            {
                return MapToEntity(dt.Rows[0]);
            }
            return null;
        }

        /// <summary>
        /// DataTable'ı List<Role>'ya dönüştürür
        /// </summary>
        private List<Role> MapToList(DataTable dt)
        {
            List<Role> list = new List<Role>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(MapToEntity(row));
            }
            return list;
        }

        /// <summary>
        /// DataRow'u Role nesnesine dönüştürür
        /// </summary>
        private Role MapToEntity(DataRow row)
        {
            return new Role
            {
                RoleID = Convert.ToInt32(row["RoleID"]),
                RoleName = row["RoleName"].ToString(),
                Description = row["Description"] != DBNull.Value ? row["Description"].ToString() : ""
            };
        }
    }
}

