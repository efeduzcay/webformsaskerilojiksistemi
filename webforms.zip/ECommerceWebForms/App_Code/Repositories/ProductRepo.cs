using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;

namespace ECommerceWebForms
{
    /// <summary>
    /// Ürün CRUD işlemleri - Parametreli sorgular
    /// </summary>
    public class ProductRepo
    {
        /// <summary>
        /// Tüm ürünleri kategori adı ile getirir
        /// </summary>
        public List<Product> GetAll()
        {
            string sql = @"SELECT p.*, c.CategoryName 
                          FROM Products p 
                          LEFT JOIN Categories c ON p.CategoryID = c.CategoryID 
                          ORDER BY p.ProductName";
            DataTable dt = Db.ExecuteQuery(sql);
            return MapToList(dt);
        }

        /// <summary>
        /// Aktif ürünleri getirir
        /// </summary>
        public List<Product> GetActive()
        {
            string sql = @"SELECT p.*, c.CategoryName 
                          FROM Products p 
                          LEFT JOIN Categories c ON p.CategoryID = c.CategoryID 
                          WHERE p.IsActive = True 
                          ORDER BY p.ProductName";
            DataTable dt = Db.ExecuteQuery(sql);
            return MapToList(dt);
        }

        /// <summary>
        /// Kategoriye göre ürünleri getirir
        /// </summary>
        public List<Product> GetByCategory(int categoryId)
        {
            string sql = @"SELECT p.*, c.CategoryName 
                          FROM Products p 
                          LEFT JOIN Categories c ON p.CategoryID = c.CategoryID 
                          WHERE p.CategoryID = ? AND p.IsActive = True 
                          ORDER BY p.ProductName";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@CategoryID", categoryId));
            return MapToList(dt);
        }

        /// <summary>
        /// ID ile ürün getirir
        /// </summary>
        public Product GetById(int productId)
        {
            string sql = @"SELECT p.*, c.CategoryName 
                          FROM Products p 
                          LEFT JOIN Categories c ON p.CategoryID = c.CategoryID 
                          WHERE p.ProductID = ?";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@ProductID", productId));
            if (dt.Rows.Count > 0)
            {
                return MapToEntity(dt.Rows[0]);
            }
            return null;
        }

        /// <summary>
        /// Ürün arama (ad veya açıklama)
        /// </summary>
        public List<Product> Search(string keyword, int? categoryId = null)
        {
            string sql = @"SELECT p.*, c.CategoryName 
                          FROM Products p 
                          LEFT JOIN Categories c ON p.CategoryID = c.CategoryID 
                          WHERE p.IsActive = True AND (p.ProductName LIKE ? OR p.Description LIKE ?)";

            List<OleDbParameter> parameters = new List<OleDbParameter>();
            parameters.Add(Db.CreateParameter("@Keyword1", "%" + keyword + "%"));
            parameters.Add(Db.CreateParameter("@Keyword2", "%" + keyword + "%"));

            if (categoryId.HasValue && categoryId.Value > 0)
            {
                sql += " AND p.CategoryID = ?";
                parameters.Add(Db.CreateParameter("@CategoryID", categoryId.Value));
            }

            sql += " ORDER BY p.ProductName";
            DataTable dt = Db.ExecuteQuery(sql, parameters.ToArray());
            return MapToList(dt);
        }

        /// <summary>
        /// Sayfalama ile ürün listesi (GridView için DataTable)
        /// </summary>
        public DataTable GetAllAsDataTable()
        {
            string sql = @"SELECT p.ProductID, p.ProductName, p.Price, p.StockQuantity, 
                          p.IsActive, p.CreatedDate, c.CategoryName 
                          FROM Products p 
                          LEFT JOIN Categories c ON p.CategoryID = c.CategoryID 
                          ORDER BY p.ProductName";
            return Db.ExecuteQuery(sql);
        }

        /// <summary>
        /// Yeni ürün ekler
        /// </summary>
        public int Insert(Product product)
        {
            string sql = @"INSERT INTO Products 
                          (ProductName, Description, Price, StockQuantity, CategoryID, ImageUrl, IsActive, CreatedDate) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            return Db.ExecuteInsertAndGetId(sql,
                Db.CreateParameter("@ProductName", OleDbType.VarChar, product.ProductName),
                Db.CreateParameter("@Description", OleDbType.LongVarChar, product.Description ?? ""),
                Db.CreateParameter("@Price", OleDbType.Currency, product.Price),
                Db.CreateParameter("@StockQuantity", OleDbType.Integer, product.StockQuantity),
                Db.CreateParameter("@CategoryID", OleDbType.Integer, product.CategoryID),
                Db.CreateParameter("@ImageUrl", OleDbType.VarChar, product.ImageUrl ?? ""),
                Db.CreateParameter("@IsActive", OleDbType.Boolean, product.IsActive),
                Db.CreateParameter("@CreatedDate", OleDbType.Date, DateTime.Now));
        }

        /// <summary>
        /// Ürün günceller
        /// </summary>
        public int Update(Product product)
        {
            string sql = @"UPDATE Products SET 
                          ProductName = ?, 
                          Description = ?, 
                          Price = ?, 
                          StockQuantity = ?, 
                          CategoryID = ?, 
                          ImageUrl = ?, 
                          IsActive = ?
                          WHERE ProductID = ?";
            return Db.ExecuteNonQuery(sql,
                Db.CreateParameter("@ProductName", OleDbType.VarChar, product.ProductName),
                Db.CreateParameter("@Description", OleDbType.LongVarChar, product.Description ?? ""),
                Db.CreateParameter("@Price", OleDbType.Currency, product.Price),
                Db.CreateParameter("@StockQuantity", OleDbType.Integer, product.StockQuantity),
                Db.CreateParameter("@CategoryID", OleDbType.Integer, product.CategoryID),
                Db.CreateParameter("@ImageUrl", OleDbType.VarChar, product.ImageUrl ?? ""),
                Db.CreateParameter("@IsActive", OleDbType.Boolean, product.IsActive),
                Db.CreateParameter("@ProductID", OleDbType.Integer, product.ProductID));
        }

        /// <summary>
        /// Ürün siler
        /// </summary>
        public int Delete(int productId)
        {
            string sql = "DELETE FROM Products WHERE ProductID = ?";
            return Db.ExecuteNonQuery(sql, Db.CreateParameter("@ProductID", productId));
        }

        /// <summary>
        /// Stok günceller
        /// </summary>
        public int UpdateStock(int productId, int quantity)
        {
            string sql = "UPDATE Products SET StockQuantity = StockQuantity - ? WHERE ProductID = ?";
            return Db.ExecuteNonQuery(sql,
                Db.CreateParameter("@Quantity", quantity),
                Db.CreateParameter("@ProductID", productId));
        }

        /// <summary>
        /// DataTable'ı List<Product>'ya dönüştürür
        /// </summary>
        private List<Product> MapToList(DataTable dt)
        {
            List<Product> list = new List<Product>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(MapToEntity(row));
            }
            return list;
        }

        /// <summary>
        /// DataRow'u Product nesnesine dönüştürür
        /// </summary>
        private Product MapToEntity(DataRow row)
        {
            return new Product
            {
                ProductID = Convert.ToInt32(row["ProductID"]),
                ProductName = row["ProductName"].ToString(),
                Description = row["Description"] != DBNull.Value ? row["Description"].ToString() : "",
                Price = Convert.ToDecimal(row["Price"]),
                StockQuantity = Convert.ToInt32(row["StockQuantity"]),
                CategoryID = Convert.ToInt32(row["CategoryID"]),
                ImageUrl = row["ImageUrl"] != DBNull.Value ? row["ImageUrl"].ToString() : "",
                IsActive = Convert.ToBoolean(row["IsActive"]),
                CreatedDate = Convert.ToDateTime(row["CreatedDate"]),
                CategoryName = row.Table.Columns.Contains("CategoryName") && row["CategoryName"] != DBNull.Value 
                    ? row["CategoryName"].ToString() : ""
            };
        }
    }
}

