using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;

namespace ECommerceWebForms
{
    /// <summary>
    /// Kullanıcı CRUD işlemleri - Parametreli sorgular
    /// </summary>
    public class UserRepo
    {
        /// <summary>
        /// Tüm kullanıcıları getirir
        /// </summary>
        public List<UserModel> GetAll()
        {
            string sql = @"SELECT u.*, r.RoleName 
                          FROM Users u 
                          LEFT JOIN Roles r ON u.RoleID = r.RoleID 
                          ORDER BY u.Username";
            DataTable dt = Db.ExecuteQuery(sql);
            return MapToList(dt);
        }

        /// <summary>
        /// ID ile kullanıcı getirir
        /// </summary>
        public UserModel GetById(int userId)
        {
            string sql = @"SELECT u.*, r.RoleName 
                          FROM Users u 
                          LEFT JOIN Roles r ON u.RoleID = r.RoleID 
                          WHERE u.UserID = ?";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@UserID", userId));
            if (dt.Rows.Count > 0)
            {
                return MapToEntity(dt.Rows[0]);
            }
            return null;
        }

        /// <summary>
        /// Kullanıcı adı ile kullanıcı getirir (Login için)
        /// </summary>
        public UserModel GetByUsername(string username)
        {
            string sql = @"SELECT u.*, r.RoleName 
                          FROM Users u 
                          LEFT JOIN Roles r ON u.RoleID = r.RoleID 
                          WHERE u.Username = ?";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@Username", username));
            if (dt.Rows.Count > 0)
            {
                return MapToEntity(dt.Rows[0]);
            }
            return null;
        }

        /// <summary>
        /// Email ile kullanıcı getirir
        /// </summary>
        public UserModel GetByEmail(string email)
        {
            string sql = @"SELECT u.*, r.RoleName 
                          FROM Users u 
                          LEFT JOIN Roles r ON u.RoleID = r.RoleID 
                          WHERE u.Email = ?";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@Email", email));
            if (dt.Rows.Count > 0)
            {
                return MapToEntity(dt.Rows[0]);
            }
            return null;
        }

        /// <summary>
        /// Kullanıcı adı mevcut mu kontrol eder
        /// </summary>
        public bool UsernameExists(string username)
        {
            string sql = "SELECT COUNT(*) FROM Users WHERE Username = ?";
            object result = Db.ExecuteScalar(sql, Db.CreateParameter("@Username", username));
            return Convert.ToInt32(result) > 0;
        }

        /// <summary>
        /// Email mevcut mu kontrol eder
        /// </summary>
        public bool EmailExists(string email)
        {
            string sql = "SELECT COUNT(*) FROM Users WHERE Email = ?";
            object result = Db.ExecuteScalar(sql, Db.CreateParameter("@Email", email));
            return Convert.ToInt32(result) > 0;
        }

        /// <summary>
        /// Yeni kullanıcı ekler (şifre hash+salt ile)
        /// </summary>
        public int Insert(UserModel UserModel, string password)
        {
            string salt = PasswordHelper.GenerateSalt();
            string hash = PasswordHelper.HashPassword(password, salt);

            string sql = @"INSERT INTO Users 
                          (Username, Email, PasswordHash, PasswordSalt, FullName, Phone, Address, RoleID, IsActive, CreatedDate) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            return Db.ExecuteInsertAndGetId(sql,
                Db.CreateParameter("@Username", UserModel.Username),
                Db.CreateParameter("@Email", UserModel.Email),
                Db.CreateParameter("@PasswordHash", hash),
                Db.CreateParameter("@PasswordSalt", salt),
                Db.CreateParameter("@FullName", UserModel.FullName),
                Db.CreateParameter("@Phone", UserModel.Phone),
                Db.CreateParameter("@Address", UserModel.Address),
                Db.CreateParameter("@RoleID", UserModel.RoleID),
                Db.CreateParameter("@IsActive", UserModel.IsActive),
                Db.CreateParameter("@CreatedDate", DateTime.Now));
        }

        /// <summary>
        /// Kullanıcı profil bilgilerini günceller (şifre hariç)
        /// </summary>
        public int Update(UserModel UserModel)
        {
            string sql = @"UPDATE Users SET 
                          Email = ?, 
                          FullName = ?, 
                          Phone = ?, 
                          Address = ?
                          WHERE UserID = ?";
            return Db.ExecuteNonQuery(sql,
                Db.CreateParameter("@Email", UserModel.Email),
                Db.CreateParameter("@FullName", UserModel.FullName),
                Db.CreateParameter("@Phone", UserModel.Phone),
                Db.CreateParameter("@Address", UserModel.Address),
                Db.CreateParameter("@UserID", UserModel.UserID));
        }

        /// <summary>
        /// Kullanıcı rolünü günceller (Admin panel için)
        /// </summary>
        public int UpdateRole(int userId, int roleId)
        {
            string sql = "UPDATE Users SET RoleID = ? WHERE UserID = ?";
            return Db.ExecuteNonQuery(sql,
                Db.CreateParameter("@RoleID", roleId),
                Db.CreateParameter("@UserID", userId));
        }

        /// <summary>
        /// Kullanıcı durumunu günceller
        /// </summary>
        public int UpdateStatus(int userId, bool isActive)
        {
            string sql = "UPDATE Users SET IsActive = ? WHERE UserID = ?";
            return Db.ExecuteNonQuery(sql,
                Db.CreateParameter("@IsActive", isActive),
                Db.CreateParameter("@UserID", userId));
        }

        /// <summary>
        /// Şifre değiştirir
        /// </summary>
        public int ChangePassword(int userId, string newPassword)
        {
            string salt = PasswordHelper.GenerateSalt();
            string hash = PasswordHelper.HashPassword(newPassword, salt);

            string sql = "UPDATE Users SET PasswordHash = ?, PasswordSalt = ? WHERE UserID = ?";
            return Db.ExecuteNonQuery(sql,
                Db.CreateParameter("@PasswordHash", hash),
                Db.CreateParameter("@PasswordSalt", salt),
                Db.CreateParameter("@UserID", userId));
        }

        /// <summary>
        /// Login doğrulama
        /// </summary>
        public UserModel ValidateLogin(string username, string password)
        {
            UserModel UserModel = GetByUsername(username);
            if (UserModel != null && UserModel.IsActive)
            {
                if (PasswordHelper.VerifyPassword(password, UserModel.PasswordHash, UserModel.PasswordSalt))
                {
                    return UserModel;
                }
            }
            return null;
        }

        /// <summary>
        /// DataTable'ı List<UserModel>'ya dönüştürür
        /// </summary>
        private List<UserModel> MapToList(DataTable dt)
        {
            List<UserModel> list = new List<UserModel>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(MapToEntity(row));
            }
            return list;
        }

        /// <summary>
        /// DataRow'u UserModel nesnesine dönüştürür
        /// </summary>
        private UserModel MapToEntity(DataRow row)
        {
            return new UserModel
            {
                UserID = Convert.ToInt32(row["UserID"]),
                Username = row["Username"].ToString(),
                Email = row["Email"].ToString(),
                PasswordHash = row["PasswordHash"].ToString(),
                PasswordSalt = row["PasswordSalt"].ToString(),
                FullName = row["FullName"] != DBNull.Value ? row["FullName"].ToString() : "",
                Phone = row["Phone"] != DBNull.Value ? row["Phone"].ToString() : "",
                Address = row["Address"] != DBNull.Value ? row["Address"].ToString() : "",
                RoleID = Convert.ToInt32(row["RoleID"]),
                IsActive = Convert.ToBoolean(row["IsActive"]),
                CreatedDate = Convert.ToDateTime(row["CreatedDate"]),
                RoleName = row.Table.Columns.Contains("RoleName") && row["RoleName"] != DBNull.Value 
                    ? row["RoleName"].ToString() : ""
            };
        }
    }
}

