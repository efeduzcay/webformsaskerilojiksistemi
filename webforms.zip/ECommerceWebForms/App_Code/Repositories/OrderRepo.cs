using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;

namespace ECommerceWebForms
{
    /// <summary>
    /// Sipariş CRUD işlemleri - Parametreli sorgular
    /// </summary>
    public class OrderRepo
    {
        /// <summary>
        /// Tüm siparişleri getirir (Admin için)
        /// </summary>
        public List<Order> GetAll()
        {
            string sql = @"SELECT o.*, u.FullName AS CustomerName 
                          FROM Orders o 
                          LEFT JOIN Users u ON o.UserID = u.UserID 
                          ORDER BY o.OrderDate DESC";
            DataTable dt = Db.ExecuteQuery(sql);
            return MapToList(dt);
        }

        /// <summary>
        /// Kullanıcının siparişlerini getirir
        /// </summary>
        public List<Order> GetByUserId(int userId)
        {
            string sql = @"SELECT o.*, u.FullName AS CustomerName 
                          FROM Orders o 
                          LEFT JOIN Users u ON o.UserID = u.UserID 
                          WHERE o.UserID = ? 
                          ORDER BY o.OrderDate DESC";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@UserID", userId));
            return MapToList(dt);
        }

        /// <summary>
        /// ID ile sipariş getirir
        /// </summary>
        public Order GetById(int orderId)
        {
            string sql = @"SELECT o.*, u.FullName AS CustomerName 
                          FROM Orders o 
                          LEFT JOIN Users u ON o.UserID = u.UserID 
                          WHERE o.OrderID = ?";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@OrderID", orderId));
            if (dt.Rows.Count > 0)
            {
                Order order = MapToEntity(dt.Rows[0]);
                order.OrderDetails = GetOrderDetails(orderId);
                return order;
            }
            return null;
        }

        /// <summary>
        /// Sipariş detaylarını getirir
        /// </summary>
        public List<OrderDetail> GetOrderDetails(int orderId)
        {
            string sql = @"SELECT od.*, p.ProductName, p.ImageUrl AS ProductImage 
                          FROM OrderDetails od 
                          LEFT JOIN Products p ON od.ProductID = p.ProductID 
                          WHERE od.OrderID = ?";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@OrderID", orderId));

            List<OrderDetail> list = new List<OrderDetail>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(new OrderDetail
                {
                    OrderDetailID = Convert.ToInt32(row["OrderDetailID"]),
                    OrderID = Convert.ToInt32(row["OrderID"]),
                    ProductID = Convert.ToInt32(row["ProductID"]),
                    Quantity = Convert.ToInt32(row["Quantity"]),
                    UnitPrice = Convert.ToDecimal(row["UnitPrice"]),
                    TotalPrice = Convert.ToDecimal(row["TotalPrice"]),
                    ProductName = row["ProductName"] != DBNull.Value ? row["ProductName"].ToString() : "",
                    ProductImage = row["ProductImage"] != DBNull.Value ? row["ProductImage"].ToString() : ""
                });
            }
            return list;
        }

        /// <summary>
        /// Yeni sipariş oluşturur (Transaction ile)
        /// </summary>
        public int CreateOrder(Order order, List<CartItem> cartItems)
        {
            using (OleDbConnection conn = Db.GetConnection())
            {
                conn.Open();
                OleDbTransaction transaction = conn.BeginTransaction();

                try
                {
                    // Siparişi oluştur
                    string orderSql = @"INSERT INTO Orders 
                                       (UserID, OrderDate, TotalAmount, Status, ShippingAddress, Notes) 
                                       VALUES (?, ?, ?, ?, ?, ?)";
                    
                    OleDbCommand orderCmd = new OleDbCommand(orderSql, conn, transaction);
                    orderCmd.Parameters.Add("@UserID", OleDbType.Integer).Value = order.UserID;
                    orderCmd.Parameters.Add("@OrderDate", OleDbType.Date).Value = DateTime.Now;
                    orderCmd.Parameters.Add("@TotalAmount", OleDbType.Currency).Value = order.TotalAmount;
                    orderCmd.Parameters.Add("@Status", OleDbType.VarChar, 50).Value = "Beklemede";
                    orderCmd.Parameters.Add("@ShippingAddress", OleDbType.LongVarChar).Value = order.ShippingAddress ?? "";
                    orderCmd.Parameters.Add("@Notes", OleDbType.LongVarChar).Value = order.Notes ?? "";
                    orderCmd.ExecuteNonQuery();

                    // Oluşan OrderID'yi al
                    orderCmd.CommandText = "SELECT @@IDENTITY";
                    orderCmd.Parameters.Clear();
                    int orderId = Convert.ToInt32(orderCmd.ExecuteScalar());

                    // Sipariş detaylarını ekle
                    foreach (CartItem item in cartItems)
                    {
                        string detailSql = @"INSERT INTO OrderDetails 
                                            (OrderID, ProductID, Quantity, UnitPrice, TotalPrice) 
                                            VALUES (?, ?, ?, ?, ?)";
                        OleDbCommand detailCmd = new OleDbCommand(detailSql, conn, transaction);
                        detailCmd.Parameters.Add("@OrderID", OleDbType.Integer).Value = orderId;
                        detailCmd.Parameters.Add("@ProductID", OleDbType.Integer).Value = item.ProductID;
                        detailCmd.Parameters.Add("@Quantity", OleDbType.Integer).Value = item.Quantity;
                        detailCmd.Parameters.Add("@UnitPrice", OleDbType.Currency).Value = item.UnitPrice;
                        detailCmd.Parameters.Add("@TotalPrice", OleDbType.Currency).Value = item.UnitPrice * item.Quantity;
                        detailCmd.ExecuteNonQuery();

                        // Stok düşür
                        string stockSql = "UPDATE Products SET StockQuantity = StockQuantity - ? WHERE ProductID = ?";
                        OleDbCommand stockCmd = new OleDbCommand(stockSql, conn, transaction);
                        stockCmd.Parameters.Add("@Quantity", OleDbType.Integer).Value = item.Quantity;
                        stockCmd.Parameters.Add("@ProductID", OleDbType.Integer).Value = item.ProductID;
                        stockCmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return orderId;
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        /// <summary>
        /// Sipariş durumunu günceller
        /// </summary>
        public int UpdateStatus(int orderId, string status, DateTime? deliveryDate = null)
        {
            string sql = "UPDATE Orders SET Status = ?, DeliveryDate = ? WHERE OrderID = ?";
            return Db.ExecuteNonQuery(sql,
                Db.CreateParameter("@Status", status),
                Db.CreateParameter("@DeliveryDate", deliveryDate),
                Db.CreateParameter("@OrderID", orderId));
        }

        /// <summary>
        /// Duruma göre sipariş sayısı
        /// </summary>
        public int GetCountByStatus(string status)
        {
            string sql = "SELECT COUNT(*) FROM Orders WHERE Status = ?";
            object result = Db.ExecuteScalar(sql, Db.CreateParameter("@Status", status));
            return result != null ? Convert.ToInt32(result) : 0;
        }

        /// <summary>
        /// DataTable'ı List<Order>'ya dönüştürür
        /// </summary>
        private List<Order> MapToList(DataTable dt)
        {
            List<Order> list = new List<Order>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(MapToEntity(row));
            }
            return list;
        }

        /// <summary>
        /// DataRow'u Order nesnesine dönüştürür
        /// </summary>
        private Order MapToEntity(DataRow row)
        {
            return new Order
            {
                OrderID = Convert.ToInt32(row["OrderID"]),
                UserID = Convert.ToInt32(row["UserID"]),
                OrderDate = Convert.ToDateTime(row["OrderDate"]),
                DeliveryDate = row["DeliveryDate"] != DBNull.Value ? (DateTime?)Convert.ToDateTime(row["DeliveryDate"]) : null,
                TotalAmount = Convert.ToDecimal(row["TotalAmount"]),
                Status = row["Status"].ToString(),
                ShippingAddress = row["ShippingAddress"] != DBNull.Value ? row["ShippingAddress"].ToString() : "",
                Notes = row["Notes"] != DBNull.Value ? row["Notes"].ToString() : "",
                CustomerName = row.Table.Columns.Contains("CustomerName") && row["CustomerName"] != DBNull.Value 
                    ? row["CustomerName"].ToString() : ""
            };
        }
    }
}

