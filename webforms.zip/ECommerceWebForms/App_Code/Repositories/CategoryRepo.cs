using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;

namespace ECommerceWebForms
{
    /// <summary>
    /// Kategori CRUD işlemleri - Parametreli sorgular
    /// </summary>
    public class CategoryRepo
    {
        /// <summary>
        /// Tüm kategorileri getirir
        /// </summary>
        public List<Category> GetAll()
        {
            string sql = "SELECT * FROM Categories ORDER BY CategoryName";
            DataTable dt = Db.ExecuteQuery(sql);
            return MapToList(dt);
        }

        /// <summary>
        /// Aktif kategorileri getirir
        /// </summary>
        public List<Category> GetActive()
        {
            string sql = "SELECT * FROM Categories WHERE IsActive = True ORDER BY CategoryName";
            DataTable dt = Db.ExecuteQuery(sql);
            return MapToList(dt);
        }

        /// <summary>
        /// ID ile kategori getirir
        /// </summary>
        public Category GetById(int categoryId)
        {
            string sql = "SELECT * FROM Categories WHERE CategoryID = ?";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@CategoryID", categoryId));
            if (dt.Rows.Count > 0)
            {
                return MapToEntity(dt.Rows[0]);
            }
            return null;
        }

        /// <summary>
        /// Kategori adına göre arama
        /// </summary>
        public List<Category> Search(string keyword)
        {
            string sql = "SELECT * FROM Categories WHERE CategoryName LIKE ? ORDER BY CategoryName";
            DataTable dt = Db.ExecuteQuery(sql, Db.CreateParameter("@Keyword", "%" + keyword + "%"));
            return MapToList(dt);
        }

        /// <summary>
        /// Yeni kategori ekler
        /// </summary>
        public int Insert(Category category)
        {
            string sql = @"INSERT INTO Categories (CategoryName, Description, IsActive, CreatedDate) 
                          VALUES (?, ?, ?, ?)";
            return Db.ExecuteInsertAndGetId(sql,
                Db.CreateParameter("@CategoryName", OleDbType.VarChar, category.CategoryName),
                Db.CreateParameter("@Description", OleDbType.LongVarChar, category.Description ?? ""),
                Db.CreateParameter("@IsActive", OleDbType.Boolean, category.IsActive),
                Db.CreateParameter("@CreatedDate", OleDbType.Date, DateTime.Now));
        }

        /// <summary>
        /// Kategori günceller
        /// </summary>
        public int Update(Category category)
        {
            string sql = @"UPDATE Categories SET 
                          CategoryName = ?, 
                          Description = ?, 
                          IsActive = ?
                          WHERE CategoryID = ?";
            return Db.ExecuteNonQuery(sql,
                Db.CreateParameter("@CategoryName", OleDbType.VarChar, category.CategoryName),
                Db.CreateParameter("@Description", OleDbType.LongVarChar, category.Description ?? ""),
                Db.CreateParameter("@IsActive", OleDbType.Boolean, category.IsActive),
                Db.CreateParameter("@CategoryID", OleDbType.Integer, category.CategoryID));
        }

        /// <summary>
        /// Kategori siler (fiziksel silme)
        /// </summary>
        public int Delete(int categoryId)
        {
            string sql = "DELETE FROM Categories WHERE CategoryID = ?";
            return Db.ExecuteNonQuery(sql, Db.CreateParameter("@CategoryID", categoryId));
        }

        /// <summary>
        /// Kategoriye bağlı ürün sayısını döndürür
        /// </summary>
        public int GetProductCount(int categoryId)
        {
            string sql = "SELECT COUNT(*) FROM Products WHERE CategoryID = ?";
            object result = Db.ExecuteScalar(sql, Db.CreateParameter("@CategoryID", categoryId));
            return result != null ? Convert.ToInt32(result) : 0;
        }

        /// <summary>
        /// DataTable'ı List<Category>'ye dönüştürür
        /// </summary>
        private List<Category> MapToList(DataTable dt)
        {
            List<Category> list = new List<Category>();
            foreach (DataRow row in dt.Rows)
            {
                list.Add(MapToEntity(row));
            }
            return list;
        }

        /// <summary>
        /// DataRow'u Category nesnesine dönüştürür
        /// </summary>
        private Category MapToEntity(DataRow row)
        {
            return new Category
            {
                CategoryID = Convert.ToInt32(row["CategoryID"]),
                CategoryName = row["CategoryName"].ToString(),
                Description = row["Description"] != DBNull.Value ? row["Description"].ToString() : "",
                IsActive = Convert.ToBoolean(row["IsActive"]),
                CreatedDate = Convert.ToDateTime(row["CreatedDate"])
            };
        }
    }
}

