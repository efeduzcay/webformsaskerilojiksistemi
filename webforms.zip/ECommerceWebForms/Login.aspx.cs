using System;
using System.Web.Security;

namespace ECommerceWebForms
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Zaten giriş yapmışsa ana sayfaya yönlendir
            if (Session["UserID"] != null)
            {
                Response.Redirect("~/Default.aspx");
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            if (!Page.IsValid) return;

            try
            {
                UserRepo userRepo = new UserRepo();
                UserModel UserModel = userRepo.ValidateLogin(txtUsername.Text.Trim(), txtPassword.Text);

                if (UserModel != null)
                {
                    // Session'a kullanıcı bilgilerini kaydet
                    Session["UserID"] = UserModel.UserID;
                    Session["Username"] = UserModel.Username;
                    Session["FullName"] = UserModel.FullName;
                    Session["RoleID"] = UserModel.RoleID;
                    Session["RoleName"] = UserModel.RoleName;

                    // Forms Authentication cookie
                    FormsAuthentication.SetAuthCookie(UserModel.Username, chkRemember.Checked);

                    // Return URL varsa oraya, yoksa ana sayfaya yönlendir
                    string returnUrl = Request.QueryString["returnUrl"];
                    if (!string.IsNullOrEmpty(returnUrl))
                    {
                        Response.Redirect(returnUrl);
                    }
                    else if (UserModel.RoleID == 1) // Admin
                    {
                        Response.Redirect("~/Admin/Default.aspx");
                    }
                    else
                    {
                        Response.Redirect("~/Default.aspx");
                    }
                }
                else
                {
                    ShowError("Kullanıcı adı veya şifre hatalı!");
                }
            }
            catch (Exception ex)
            {
                ShowError("Giriş sırasında bir hata oluştu: " + ex.Message);
            }
        }

        private void ShowError(string message)
        {
            pnlMessage.Visible = true;
            lblMessage.CssClass = "alert alert-danger";
            lblMessage.Text = message;
        }
    }
}

